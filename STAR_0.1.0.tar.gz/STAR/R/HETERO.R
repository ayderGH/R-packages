#' *******************************************************************************
#' Test for and treatment of heteroscedasticity -- See Stringer & Stewart s 8.5
#' *******************************************************************************
hetero <- function() {
    x <- as.double()            # absolute x value
    e <- as.double()            # absolute residual 
    s_x <- as.double()          # sum of absolute x 
    s_e <- as.double()          # sum of absolute e 
    s_x2 <- as.double()         # sum of squares of x 
    s_e2 <- as.double()         # sum of squares of e 
    s_xe <- as.double()         # sum of cross-prod, abs x vs abs e 
    r <- as.double()            # coeff of correlation 
    r_max <- as.double()        # highest correlation between x's and residuals 
    F <- as.double()            # F-statistic 
    F_prob <- as.double()       # Tail probability of F statistic 
    real_k <- as.integer()      # number of non-seasonal independent variables 
    w <- as.integer()           # x-variable most significantly correlated 
    n <- as.integer()           # number of observations in base 
    n1 <- n2 <- as.integer()    # first and last obs 
    df_den <- as.integer()      # degrees of freedom -- denominator 
    i <- j <- as.integer()      # loop variables 
    
    # initialization
    r <- r_max <- 0
    w <- 0
    
    # Find highest correlation between indep vars and abs resids
    n <- star.env$n_last_base - star.env$n_first_base + 1
    
    # correlation is sought with non-seasonals only
    real_k <- ifelse(star.env$seas_adj, star.env$k - star.env$periods_per_year, star.env$k)
    
    for (j in 1:real_k) {
        if (star.env$beta[j+1] == 0) {
            next  # Skip if the X variable is not in the regression
        }
        
        s_x <- s_x2 <- s_xe <- s_e <- s_e2 <- 0
      
        # calculate statistics for heteroscedasticity tests
        for (i in star.env$n_first_base:star.env$n_last_base) {
            x <- abs(get_x(i, j))
            s_x <- s_x + x
            s_x2 <- s_x2 + x * x
            e <- abs(residual(i, 0, 0))
            s_e <- s_e + e
            s_e2 <- s_e2 + e * e
            s_xe <- s_xe + x * e
        }
        
        # set r = denominator of coeff of correlation and test
        r <- (s_x2 - s_x * s_x / n) * (s_e2  -  s_e * s_e / n)
        if (r <= 0) {
            next
        }
        
        r <- sqrt(r)
        r <- (s_xe - s_x * s_e / n) / r
        r <- abs(r)
        if (r > r_max) {
            r_max <- r
            w <- j
        }
    }
    
    # Apply F test for significance of r_max -- Stringer & Stewart p 185
    df_den <- n - 2
    F <- r_max * r_max / ((1.0 - r_max * r_max) / df_den)
    F_prob <- F_test(F, 1, df_den)
    
    # print details of test
    var_symbol <- star.env$variable$symbol[w+1]
    
    add_report("HETERO", "variable", var_symbol)
    add_report("HETERO", "r_max", r_max)
    add_report("HETERO", "df_den", df_den)
    add_report("HETERO", "F", F)
    add_report("HETERO", "F_prob", F_prob)
    add_report("HETERO", "star.env$SIGLEV_HETERO", star.env$SIGLEV_HETERO)
    
    w <- ifelse(F_prob < star.env$SIGLEV_HETERO, w, 0)
    
    add_report("HETERO", "w", w)

    # action if residuals are heteroscedastic
    if (w != 0) {
        add_report("HETERO", "message", "residuals are heteroscedastic")
        add_report("HETERO", "variable_name", star.env$variable$symbol[w+1])
        
        n1 <- star.env$n_first_base
        n2 <- max(star.env$n_last_base, star.env$n_last_proj)
        
        for (i in n1:n2)
            if (get_x(i, w) == 0) {
                add_report("HETERO", "variable_name", star.env$variable$symbol[w+1])
                add_report("HETERO", "loop variable", i+1)
                return (w <- star.env$FATAL_HETEROSCEDASTICITY)
            }
        
        # Transform variables ; perform weighted least squares
        correlate(star.env$n_first_base, star.env$n_last_base, w, 0)
        
        for (j in 1:star.env$k) {
            if (star.env$beta[j+1] != 0 & star.env$x_x[j+1, j+1] > star.env$TOLERANCE)
                gauss_jordan(j)
        }
        
        calc_function()
        
        # Re-test for heteroscedasticity
        s_x <- s_x2 <- s_xe <- s_e <- s_e2 <- 0
        
        # calculate statistics for heteroscedasticity test
        for ( i in star.env$n_first_base:star.env$n_last_base) {
            x <- abs (1.0  / get_x (i, w) )
            s_x <- s_x + x
            s_x2 <- s_x2 + x * x
            e <- abs(residual(i, w, 0))
            s_e <- s_e + e
            s_e2 <- s_e2 + e * e
            s_xe <- s_xe + x * e
        }
        
        # set r = denominator of coeff of correlation and test
        r <- (s_x2  -  s_x * s_x / n) * (s_e2  -  s_e * s_e / n)
        if (r <= 0) {
            return (w)
        }
        r <- sqrt (r)
        r <- (s_xe  -  s_x * s_e / n)  /  r
        
        # Apply F test for significance of r_max -- Stringer & Stewart p 185 
        df_den <- n - 2
        F <- r * r  /  ((1 - r * r) / df_den)
        F_prob <-  F_test (F, 1, df_den)
        
        # print details of test 
        add_report("HETERO", "r", r)
        add_report("HETERO", "df_den", df_den)
        add_report("HETERO", "F", F)
        add_report("HETERO", "F_prob", F_prob)
        add_report("HETERO", "star.env$SIGLEV_HETERO", star.env$SIGLEV_HETERO)
        
        if (F_prob < star.env$SIGLEV_HETERO) {
            return (star.env$FATAL_HETEROSCEDASTICITY - 1)
        }
    }
    
    return(w)
}