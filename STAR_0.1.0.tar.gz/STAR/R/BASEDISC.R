# ***************************************************************************
# basedisc.R
# ***************************************************************************  

#' Perform Chow test for discontinuity in the base period
#' See Stringer & Stewart section 8.3.1, p 169
base_discontinuity <- function() {
    sse_1 <- as.double()              # residual sum of squares for first subperiod
    sse_2 <- as.double()              # residual sum of squares for second subperiod 
    F <- as.double()                  # F statistic for Chow test
    F_prob <- as.double()             # tail probability for F statistic 
    k_in <- as.integer()              # number of independent variables in regression
    df_num <- df_den <- as.integer()  # degrees of freedom for F test
    
    add_report("BASEDISC", "status", "start")
  
    # the calculations for the two subperiods destroy the matrix and statistics
    # calculated for the entire base. The base statistics therefore have to be
    # stored and then restored
  
    store_stats()
    if (star.env$ExitCode) {
        add_report("BASEDISC", "status", "finish")
        return(star.env$ExitCode)
    }
  
    # sums of squares for the two base subperiods
    sse_1 <- sum_of_squares (star.env$n_first_base, star.env$n_last_base - star.env$periods_per_year)
    sse_2 <- sum_of_squares (star.env$n_last_base - star.env$periods_per_year + 1, star.env$n_last_base)
  
    # restore statistics -- see the comment above
    restore_stats()
  
    # count the independent variables in the regression
    k_in <- variable_count()
  
    # degrees of freedom for numerator
    df_num <- k_in + 1
  
    # degrees of freedom for denumerator
    df_den <- (star.env$n_last_base - star.env$n_first_base + 1) - 2 * k_in - 2
  
    # F statistic for Chow Test -- see Stringer & Stewart p 170
    F <- ((star.env$sse - (sse_1 + sse_2)) / df_num) / ((sse_1 + sse_2) / df_den)
    # get tail probability for F distributed staistic
    F_prob <- F_test(F, df_num, df_den)
  
    # print details of test
    add_report("BASEDISC", "sse", star.env$sse)
    add_report("BASEDISC", "sse_1", sse_1)
    add_report("BASEDISC", "sse_2", sse_2)
  
    # denominator
    add_report("BASEDISC", "df_num", df_num)
  
    # numerator
    add_report("BASEDISC", "df_den", df_den)
  
    add_report("BASEDISC", "F", F)
    add_report("BASEDISC", "F_prob", F_prob*100)
    add_report("BASEDISC", "star.env$SIGLEV_DISC_BASE", star.env$SIGLEV_DISC_BASE*100)
  
    add_report("BASEDISC", "status", "finish")
  
    if (F_prob < star.env$SIGLEV_DISC_BASE)
        return(1)
    else
       return(0)
}