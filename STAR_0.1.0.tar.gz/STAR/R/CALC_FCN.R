#' Calculate a regression function from the transformed matrix
#' and other statistics.
#'
#' Stringer & Stewart sections 9.4 and 9.5
calc_function <- function() {

    # correct for possible pathological conditions
    star.env$x_x[1, 1] <- max(0, star.env$x_x[1, 1])
    star.env$x_x[1, 1] <- min(1, star.env$x_x[1, 1])
   
    # regression constant starts off being set to mean of dependent variable
    star.env$beta[1] <- star.env$xbar[1]
  
    # standard error of the regression function -- Stringer and Stewart p 49
    # See also Stringer & Stewart p 223. The element Byy on p 223 is star.env$x_x[1, 1] here
    star.env$std_err_beta[1]  <-  star.env$sqrt_ss_x[1] * sqrt(star.env$x_x[1, 1] / star.env$df)
  
    # sum of squares of errors -- a.k.a. residual sum of squares
    star.env$sse <- star.env$std_err_beta[1] * star.env$std_err_beta[1] * star.env$df
  
    # coefficient of correlation -- Stringer & Stewart p 222 and 223
    star.env$correlation_coefficient <- sqrt(1 - star.env$x_x[1, 1])

    # calculate coefficients of x variables and their std errors
    for (j in 1:star.env$k) {
        star.env$beta[j+1] <- 0
        star.env$std_err_beta[j+1] <- 0
        
        # if the variable is in the regression and there are no pathological conditions
        # then calculate beta and the standard error of beta, else they will be 0.0.
        # See Stringer & Stewart p 232 for explanation of the test for whether
        # x is in the regression.
        if (star.env$x_x[j+1, 1] * star.env$x_x[1, j+1] < 0 &
            star.env$x_x[j+1, j+1] > star.env$TOLERANCE &
            star.env$sqrt_ss_x[j+1] > 0) 
        {
            # See Stringer & Stewart p 217 and 222 for beta formula
            star.env$beta[j+1] <- star.env$x_x[j+1, 1] * star.env$sqrt_ss_x[1] / star.env$sqrt_ss_x[j+1]
            
            # See Stringer & Stewart p 223 for std_err_beta formula
            star.env$std_err_beta[j+1] <- star.env$std_err_beta[1] * sqrt(star.env$x_x[j+1, j+1]) / star.env$sqrt_ss_x[j+1]
            
            # regression constant. Stringer & Stewart p 217
            star.env$beta[1] <- star.env$beta[1] - star.env$beta[j+1] * star.env$xbar[j+1]
        } 
    }
}