#' Test for abnormality in the base residuals.
#' Separate tests are performed for skewness (left and right) and for kurtosis.
#' If abnormality is detected appropriate warning messages are printed.
#' No further action is taken.
#' The tests are not performed if there are less than 4 degrees of freedom.
#' 
#' See Stringer & Stewart section 8.6.
abnormality <- function() {
    
    add_report("ABNORM", "status", "start")
    
    if (star.env$df < 4) {
        return(0)
    }

    # initialization
    skewness <- kurtosis <- 0
    m2 <- m3 <- m4 <- 0.0
    v <- star.env$df

    # calculate statistics for abnormality tests */
    for (i in star.env$n_first_base:star.env$n_last_base) {
        e <- residual(i, 0, 0.0)
        m2 <- m2 + e*e
        m3 <- m3 + e*e*e
        m4 <- m4 + e*e*e*e
    }   
    
    n <- star.env$n_last_base - star.env$n_first_base + 1
    
    # moments -- Stringer & Stewart page 188
    m2 <- m2 / n
    m3 <- m3 / n
    m4 <- m4 / n

    # cumulants -- Stringer & Stewart page 188
    k2 <- v / (v-1) * m2
    k3 <- v*v / ((v-1)*(v-2)) * m3
    k4 <- v*v / ((v-1)*(v-2)*(v-3)) * ((v+1)*m4 - 3*(v-1)*m2*m2)

    # calculate a normal percentile given the significance level
    z <- 1.0  / (star.env$SIGLEV_ABNORM / 2.0)
    z <- sqrt (log (z * z))
    z <- z - (star.env$C_C0 + star.env$C_C1*z + star.env$C_C2*z*z) / (1.0 + star.env$C_D1*z + star.env$C_D2*z*z + star.env$C_D3*z*z*z)
    
    # test for skewness -- Stringer & Stewart page 189
    skew_test <- sqrt ((v-1)*(v-2) / (6*v))  *  k3 / k2^1.5
    skew_var <- 1.0 -  6.0/v + 22.0/(v*v) - 70.0/(v*v*v);
    
    if (skew_var > 0.0)
    {
        skew_crit <- z * sqrt(skew_var);
        if (abs (skew_test) > skew_crit) {
            skewness <- ifelse(skew_test > 0, 1, -1)
        }
    }
    
    # test for kurtosis -- Stringer & Stewart page 190
    kurt_test <- sqrt ( (v-1)*(v-2)*(v-3) / (24*v*(v+1)) ) * k4 / (k2*k2)
    kurt_var <- 1 - 12.0/v + 88.0/(v*v) - 532.0/(v*v*v)
    
    if (kurt_var > 0.0)
    {
        kurt_crit <- z * sqrt(kurt_var)
        if (abs(kurt_test) > kurt_crit) {
            kurtosis <- 1
        }
    }
    
    # print details of abnormality tests
    # moments 
    add_report("ABNORM", "m2", m2)
    add_report("ABNORM", "m3", m3)
    add_report("ABNORM", "m4", m4)
    
    # cumulants
    add_report("ABNORM", "k2", k2)
    add_report("ABNORM", "k3", k3)
    add_report("ABNORM", "k4", k4)
    
    # normal precentile used in test
    add_report("ABNORM", "star.env$SIGLEV_ABNORM", star.env$SIGLEV_ABNORM * 100) 
    add_report("ABNORM", "z", z)
    
    # Test for skewness
    add_report("ABNORM", "skew_test", skew_test) 
    add_report("ABNORM", "skew_var", skew_var) 
    add_report("ABNORM", "skew_crit", skew_crit) 
    
    # Test for Kurtosis
    add_report("ABNORM", "kurt_test", kurt_test) 
    add_report("ABNORM", "kurt_var", kurt_var) 
    add_report("ABNORM", "kurt_crit", kurt_crit) 
    
    add_report("ABNORM", "skewness", skewness) 
    add_report("ABNORM", "kurtosis", kurtosis)
    
    add_report("ABNORM", "status", "finish")
    
    return(skewness | kurtosis)
}