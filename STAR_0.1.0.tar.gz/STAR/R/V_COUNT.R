# ***************************************************************************
# v_count.R
# ****************************************************************************

#' Count the number of independent variables in a regression function.
#' A variable is in the regression if its coefficient (beta) is non-zero. Hence
#' this function returns the number of non-zero betas.
#' @return (int) number of non-zero betas
variable_count <- function() {
    k_in <- 0
    
    # count non-zero betas
    for (j in 1:star.env$k) {
        if (star.env$beta[j+1] != 0) {
            k_in <- k_in + 1
        }
    }
    
    return(k_in)
}
  