#' Transform matrix to adjust for admission or elimination of X variable.
#' Stringer & Stewart section 9.2.1 p 211ff and p 232.
#'
#' parameter p = pivotal element to be used for transformation
gauss_jordan <- function(p) {
    # invert pivotal element
    star.env$x_x[p+1, p+1] <- 1 / star.env$x_x[p+1, p+1]
    
    # divide row p by pivotal element (but ignore column p)
    for (j in 0:star.env$k) {
        if (j != p)
            star.env$x_x[p+1, j+1] <- star.env$x_x[p+1, j+1] * star.env$x_x[p+1, p+1]
    }
    
    # for each element in all the other rows (those other than row p)
    # subtract the p-th element in that row
    # times the equivalent element in row p (but ignore column p)
    for (i in 0:star.env$k) {
        if (i != p) {
            for (j in 0:star.env$k) {
                if (j != p) {
                    star.env$x_x[i+1, j+1] <- star.env$x_x[i+1, j+1] - star.env$x_x[i+1, p+1] * star.env$x_x[p+1, j+1]
                }
            }
        }
    }
    
    # column p becomes the element in that column
    # divided by minus the pivotal element
    for (i in 0:star.env$k) {
        if (i != p)
            star.env$x_x[i+1, p+1] <- star.env$x_x[i+1, p+1] * (-star.env$x_x[p+1, p+1])
    }
}