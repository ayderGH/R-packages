# **************************************************************************
#  P_ModSpc()
# ****************************************************************************
#  Print the specifications for the regression model
# ***************************************************************************/

P_ModSpc <- function() {
    # heading
    # add_report("P_MODSPC", "STARversion", star.env$STARversion)
  
    # dependent variable followed by independents
    if(star.env$app_type == star.env$CROSS_SECTIONAL){
        type <- c("TEST", rep("PREDICTING", star.env$k))
        vs <- data.frame(symbol = star.env$variable$symbol[1:(star.env$k + 1)],
                         name = star.env$variable$name[1:(star.env$k + 1)],
                         type = type)
    }
  
    else{
        type <- c("TEST", rep("PREDICTING", (star.env$k - star.env$seas_adj * star.env$periods_per_year)))
        vs <- data.frame(symbol = star.env$variable$symbol[1:(star.env$k - star.env$seas_adj * star.env$periods_per_year + 1)],
                         name = star.env$variable$name[1:(star.env$k - star.env$seas_adj * star.env$periods_per_year + 1)],
                         type = type)
    }
    
    if(star.env$seas_adj) vs <- rbind(vs, data.frame(symbol = "S-",
                                               name = "Seasonality",
                                               type = "PREDICTING"))
    
    # analysis of the observations used
    add_report("P_MODSPC", "variables_specified", vs)
    add_report("P_MODSPC", "n_first_base", star.env$n_first_base + 1)
    add_report("P_MODSPC", "n_last_base", star.env$n_last_base + 1)
    add_report("P_MODSPC", "total_base", star.env$n_last_base - star.env$n_first_base + 1)
    
    if (star.env$n_first_proj + 1) {
        add_report("P_MODSPC", "n_first_proj", star.env$n_first_proj + 1)
        add_report("P_MODSPC", "n_last_proj", star.env$n_last_proj + 1)
        add_report("P_MODSPC", "total_proj", star.env$n_last_proj - star.env$n_first_proj + 1)
    }
    else {
        add_report("P_MODSPC", "total_proj", 0)
    }
    
    add_report("P_MODSPC", "total", max (star.env$n_last_proj, star.env$n_last_base) - star.env$n_first_base + 1)
    
    # type of application -- time series or cross-sectional
    if (star.env$app_type == star.env$CROSS_SECTIONAL) {
        add_report("P_MODSPC", "data_profile", "CROSS-SECTIONAL")
    }
    
    if (star.env$app_type == star.env$TIME_SERIES) {
        add_report("P_MODSPC", "data_profile", "TIME SERIES")
        add_report("P_MODSPC", "periods_per_year", star.env$periods_per_year)
    }
    
    add_report("P_MODSPC", "trend_adj", ifelse(star.env$trend_adj, "REQUESTED", "NOT REQUESTED"))
    add_report("P_MODSPC", "seas_adj", ifelse(star.env$seas_adj, "REQUESTED", "NOT REQUESTED"))
    
    # Projection specifications
    add_report("P_MODSPC", "projection_type", switch(star.env$projection_type,
                                                     A = "star.env$AUDIT",
                                                     E = "ENDING BALANCE",
                                                     R = "star.env$REGRESSION",
                                                     N = "NONE"))
    
    if (star.env$projection_type == star.env$AUDIT | star.env$projection_type == star.env$END_BAL) {
        add_report("P_MODSPC", "mp_entered", star.env$mp_entered)
        add_report("P_MODSPC", "decimals", star.env$variable$decimals[1])
        add_report("P_MODSPC", "testing_strategy", star.env$testing_strategy)
        add_report("P_MODSPC", "r_factor", star.env$r_factor)
        add_report("P_MODSPC", "applicable_risk_Level", star.env$applicable_risk_Level)
    }
    
    if (star.env$projection_type == star.env$REGRESSION) {
        add_report("P_MODSPC", "conf_level", star.env$conf_level*100) 
    }
    add_report("P_MODSPC", "force_x", star.env$force_x)
}


#' **************************************************************************
#'  P_Obs()
#' ****************************************************************************
#' This function prints observations on the variables. All the real variables that
#' were specified for the regression are printed. Only those seasonal variables
#' used in the regression are printed.
P_Obs <- function(n1, n2) {
    
    # Set index and count variables to be printed, k_print
    idx <- array(0)  # index to locate variables in regression
    k_print <- 0  # number of independent variables to be printed 
    k_real <- star.env$k - star.env$seas_adj * star.env$periods_per_year  # number of real independent variables specified 
    sumx <- array()  # sum of column j
    
    for (j in 1:star.env$k) {
        if (star.env$beta[j+1] != 0 | j <= k_real) {
            k_print <- k_print + 1
            idx[k_print+1] <- j
        }
    }
    
    add_report("P_OBS", "seas_adj", star.env$seas_adj)
    add_report("P_OBS", "idx", idx)
    cnames <- c("Obs#")
    
    for (i in 1:(k_print+1)) {
        cnames[i+1] <- paste(star.env$variable$symbol[i], 
                             ifelse((star.env$beta[idx[i]+1] != 0) | (idx[i] == 0), "+", "-"),
                             sep = '')
    }
    
    add_report("P_OBS", "obs_colnames", cnames)
    
    obs <- array(cbind(c((n1+1):(n2+1)), star.env$z[(n1+1):(n2+1),idx+1]))
    add_report("P_OBS", "observations", obs)
    
    # Totals
    for (i in 1:(k_print+1)) {
        sumx[i] <- sum(as.numeric(obs[, i+1]))
    }
    
    add_report("P_OBS", "sumx", sumx)
}

#' **************************************************************************
#' P_RegMod()
#' ****************************************************************************
#' Print the regression model and related statistics
#' ***************************************************************************/
P_RegMod <- function() {
    
    # number of observations
    n <- star.env$n_last_base - star.env$n_first_base + 1
    
    # standard deviation of Y
    std_dev_y <- star.env$sqrt_ss_x[1] / sqrt (n - 1)
    
    # regression constant
    add_report("P_REGMOD", "beta_0", star.env$beta[1])
    add_report("P_REGMOD", "decimals", star.env$variable$decimals[1])
    
    # information for independent variables if any
    if (variable_count()) {
        for (j in 1:star.env$k) {
            if (star.env$beta[j+1]) {
                add_report("P_REGMOD", paste("variable", j, sep='_'), list (variable_symbol = star.env$variable$symbol[j+1],
                                                                            variable_name = star.env$variable$name[j+1],
                                                                            variable_decimals = star.env$variable$decimals[j+1],
                                                                            xbar = star.env$xbar[j+1],
                                                                            sqrt_ss_x = star.env$sqrt_ss_x[j+1] / sqrt(n - 1),
                                                                            beta = star.env$beta[j+1],
                                                                            std_err_beta = star.env$std_err_beta[j+1]))
                #add_report("P_REGMOD", paste("variable_symbol", j, sep='_'), star.env$variable$symbol[j+1])
                #add_report("P_REGMOD", paste("variable_name", j, sep='_'), star.env$variable$name[j+1])
                #add_report("P_REGMOD", paste("variable_decimals", j, sep='_'), star.env$variable$decimals[j+1]+2)
                #add_report("P_REGMOD", paste("xbar", j, sep='_'), star.env$xbar[j+1])
                #add_report("P_REGMOD", paste("sqrt_ss_x", j, sep='_'), (star.env$sqrt_ss_x[j+1] / sqrt(n - 1)))
                #add_report("P_REGMOD", paste("beta", j, sep='_'), star.env$beta[j+1])
                #add_report("P_REGMOD", paste("std_err_beta", j, sep='_'), star.env$std_err_beta[j+1])
            }
        }
    }
    
    # dependent variable information
    add_report("P_REGMOD", "variable_0", list (variable_symbol = star.env$variable$symbol[1],
                                                       variable_name = star.env$variable$name[1],
                                                       variable_decimals = star.env$variable$decimals[1],
                                                       xbar = star.env$xbar[1],
                                                       std_dev_y = std_dev_y,
                                                       std_err_beta = star.env$std_err_beta[1])) 
    #add_report("P_REGMOD", paste("variable_symbol", 0, sep='_'), star.env$variable$symbol[1])
    #add_report("P_REGMOD", paste("variable_name", 0, sep='_'), star.env$variable$name[1])
    #add_report("P_REGMOD", paste("variable_decimals", 0, sep='_'), star.env$variable$decimals[1]+2)
    #add_report("P_REGMOD", paste("xbar", 0, sep='_'), star.env$xbar[1])
    #add_report("P_REGMOD", "std_dev_y", std_dev_y)
    
    # regression estimate information
    #add_report("P_REGMOD", paste("std_err_beta", 0, sep='_'), star.env$std_err_beta[1])
    
    #if(star.env$correlation_coefficient <= 0.999)
        add_report("P_REGMOD", "correlation_coefficient", star.env$correlation_coefficient * 100)
    #else
        #add_report("P_REGMOD", "correlation_coefficient", 99.9) 
}


# **************************************************************************
#  P_Func() 
# ****************************************************************************
#  Print the formula for the regression function.
P_Func <- function(w, p) {
    
    add_report("P_FUNC", "w", w)
    add_report("P_FUNC", "p", p)
    add_report("P_FUNC", "decimals", star.env$variable$decimals[1] + 2)
    add_report("P_FUNC", "beta", star.env$beta)
    add_report("P_FUNC", "symbol", star.env$variable$symbol)
    
    # No autocorrelation and no heteroscedasticity */
    if (p == 0.0  &  w == 0){
        add_report("P_FUNC", "period", "t")
    }
    
    # Heteroscedasticity but no autocorrelation
    if (p == 0.0  &  w > 0) {
        add_report("P_FUNC", "period", "t")
        add_report("P_FUNC", "std_err_beta[0]", star.env$std_err_beta[1])
        add_report("P_FUNC", paste("symbol", w, sep = "_"), star.env$variable$symbol[w+1])
    }
    
    # Autocorrelation but no heteroscedasticity
    if (p > 0  &  w == 0) {
        first_period <- as.character(star.env$n_first_base+1)
        add_report("P_FUNC", "first_period", first_period)
        
        add_report("P_FUNC", "period", "t")
        add_report("P_FUNC", "std_err_beta[0]", star.env$std_err_beta[1])
    }
    
    # Autocorrelation and heteroscedasticity
    if (p > 0  &  w > 0) {
        first_period <- as.character(star.env$n_first_base+1)
        add_report("P_FUNC", "first_period", first_period)
        add_report("P_FUNC", paste("symbol", w, sep = "_"), star.env$variable$symbol[w+1])
        
        add_report("P_FUNC", "period", "t")
        add_report("P_FUNC", "std_err_beta[0]", star.env$std_err_beta[1])
    }
}

#' **************************************************************************
#'  P_ResPlt()
#' ****************************************************************************
#'  Print a plot of the residuals.
#' ***************************************************************************/
P_ResPlt <- function(n1, n2, w, p) {
    
    add_report("P_RESPLT", "w", w)
    add_report("P_RESPLT", "p", p)
    add_report("P_RESPLT", "n1", n1)
    add_report("P_RESPLT", "n2", n2)
    
    n1_start <- n1
    
    add_report("P_RESPLT", "n1_start", n1_start)
    add_report("P_RESPLT", "app_type", star.env$app_type)
    add_report("P_RESPLT", "periods_per_year", star.env$periods_per_year)
    
    plot_array_colnames <- c("Obs#", "Recorded Y", "Reg Estimate", "Residual Diff", "Residual / Std Err")
    plot_array <- array(dim = c(0, 5))
    
    d <- star.env$variable$decimals[1]
    add_report("P_RESPLT", "d", d)
    
    while (n1 <= n2) {
        # projected Y value
        proj <- projection (n1, w, p)
        y <- proj$y
        y_est <- proj$y_est
        e <- proj$e
        
        # standard error
        se <- ifelse(w == 0, star.env$std_err_beta[1], star.env$std_err_beta[1] * abs(get_x(i, w)))
        pos <- e / se  # not rounded because it is not for excel report
        plot_array <- rbind(plot_array, c(n1+1, y, y_est, e, pos))
        n1 <- n1 + 1
    }
    
    add_report("P_RESPLT", "plot_array_colnames", plot_array_colnames)
    add_report("P_RESPLT", "plot_array", plot_array)
}
P_Normalized_vars <- function() {
    k <- star.env$k - star.env$seas_adj * star.env$periods_per_year + 1
    n <- max (star.env$n_last_proj, star.env$n_last_base) - star.env$n_first_base + 1
    names <- star.env$variable$name[1:k]
    normalized_vars <- array(dim = c(n,0))
    for (i in 1:k) {
        x <- star.env$z[,i]
        normalized_vars <- cbind(normalized_vars, (x-min(x))/(max(x)-min(x)))
    }
    #normalized_vars <- as.data.frame(normalized_vars)
    colnames(normalized_vars) <- names
    
    add_report("P_NORM_VARS", "normalized_vars_colnames", names)
    add_report("P_NORM_VARS", "normalized_vars", normalized_vars)

}