#' Audit interface calculations for the projection period.
#' 
#' Each observation in the projection period is tested to see whether
#' there is an excess to be investigated. Where there is, an optional
#' sample is calculated.
#' 
#' Note: Using resource identifiers from EXCESS to overcome limitation of the
#' binary resource utility not being able to add new resource strings.
#' 
#' See Stringer & Stewart Chapter 5
AuditTest <- function(w, p) {
    y <- as.double()                # recorded y value
    e <- as.double()                # residual
    y_est <- as.double()            # regression estimate of y
    se_res <- as.double()           # standard error of the residual
    t <- as.double()                # t value corresponding to risk_mas
    excess_under <- as.double()     # excess to be investigated
    excess_over <- as.double()      # excess to be investigated in opposite direction 
    least_excess <- as.double()     # smallest excess to be investigated
    opt_sampl <- as.double()        # optional sample 
    sum_y <- as.double()            # sum of the recorded y's
    sum_e <- as.double()            # sum of the residuals
    sum_var <- as.double()          # sum of the variances in the projection period
    sum_y_est <- as.double()        # sum of the estimated y's
    threshold <- as.double()        # threshold for excess
    risk_at_start <- as.double()    # risk equivalent to input R factor
    risk_mas <- as.double()         # risk adjusted for most adverse spread of error
    mas <- as.double()              # most adverse spread of error
    ndec <- as.integer()            # number of decimals for y
    round_factor <- as.double()     # factor used in rounding sampling interval
    i <- as.integer()               # loop variable
    paradox_flag <- as.integer()    # flag that paradoxical excesses exist (see Stringer & Stewart p 119)
    
    
    add_report("AUDTEST", "status", "start")
    
    # initialization
    ndec <- star.env$variable$decimals[1]
    star.env$excess_count_under <- star.env$excess_count_over <- 0
    round_factor <- 10.0^ndec
    sum_y <- sum_e <- sum_y_est <- sum_var <- 0.0
    risk_at_start <- exp(-star.env$r_factor)
    paradox_flag <- star.env$OFF

    # we will not investigate excesses smaller than least sig digit
    least_excess <- 1.0 / round_factor

    # Calculate std error inverse matrix
    invert_matrix()
    
    add_report("AUDTEST", "mp_entered", star.env$mp_entered)
    add_report("AUDTEST", "ndec", ndec)
    add_report("AUDTEST", "testing_strategy", star.env$testing_strategy)
    add_report("AUDTEST", "r_factor", star.env$r_factor)
    audit_test_array <- array(dim = c(0,8))

    # This next line seems silly, but it initializes the previous residual
    # (to the last base period). It is needed in case of autocorrelation.
    # If this is not done the last base period residual (a static
    # double in residual()) may not be correct in certain circumstances
    # (eg, if the residuals have just been plotted)
    
    proj <- projection(ifelse(star.env$n_first_proj > 0, star.env$n_first_proj - 1, 0), w, p)
    y <- proj$y
    y_est <- proj$y_est
    e <- proj$e

    # Main loop begins here with input from projection profile
    for (i in star.env$n_first_proj:star.env$n_last_proj)
    {
        # print observation number if mathematical printout required
        add_report("EXCESS", "i", i+1)

        # initialize
        excess_under <- excess_over <- 0.0

        # get y, and calculate y_est, e
        proj <- projection(i, w, p)
        y <- proj$y
        y_est <- proj$y_est
        e <- proj$e

        # Calculate standard error of projection
        se_res <- standard_error(i, w, p)

        # Calculate most adverse spread of error and associated risk
        mas <- most_adverse_spread(star.env$r_factor, star.env$mp, se_res)
        
        if (star.env$ExitCode)
        {
            return()
        }
        
        risk_mas <- risk_at_start^(1.0 / mas)
        
        # print details of MAS and risk
        add_report("P_RISK", "risk_at_start", risk_at_start)
        add_report("P_RISK", "mas", mas)
        add_report("P_RISK", "risk_mas", risk_mas)

        # calculate threshold and excess
        t <- t_value(risk_mas, star.env$df)
        threshold <- star.env$mp / mas + se_res * t

        # cap threshold at mp if theshold is positive or at -mp if it is negative -- v3.20, July 2010
        threshold <- ifelse(threshold >= 0, min(threshold, star.env$mp), max(threshold, -star.env$mp))

        if (e + threshold < -least_excess)
        {
            excess_under <- e + threshold
            star.env$excess_count_under <- star.env$excess_count_under + 1
        }

        if (e - threshold > least_excess)
        {
            excess_over <- e - threshold
            star.env$excess_count_over <- star.env$excess_count_over + 1 
        }
        
        add_report("EXCESS", "df", star.env$df)
        add_report("EXCESS", "risk_mas", risk_mas)
        add_report("EXCESS", "mp_entered", star.env$mp_entered)
        add_report("EXCESS", "mas", mas)
        add_report("EXCESS", "se_res", se_res)
        add_report("EXCESS", "t", t)
        add_report("EXCESS", "threshold", threshold)
        add_report("EXCESS", "e", e)
        add_report("EXCESS", "excess_under", excess_under)
        add_report("EXCESS", "excess_over", excess_over)
        
        #add_report("AUDTEST", "y", y)
        #add_report("AUDTEST", "y_est", y_est)
        #add_report("AUDTEST", "e", e)
        #add_report("AUDTEST", "threshold", threshold)

        # paradoxical excess ?
        if (threshold < 0 & (excess_under | excess_over))
        {
            paradox_flag <- star.env$ON
        }

        audit_test_array <- rbind(audit_test_array,
                                  c(i+1, y, y_est, e, -threshold,
                                    threshold, excess_under, excess_over))
        # Accumulate totals
        sum_y <- sum_y + round(y, ndec)
        sum_y_est <- sum_y_est + round (y_est, ndec)
        sum_e <- sum_e + round (e, ndec)
        sum_var <- sum_var + se_res * se_res
    }
    
    add_report("AUDTEST", "audit_test_array_colnames",
               c("Obs#", "Recorded Y", "Reg Estimate", "Residual Diff", 
                 "Thresh Under", "Thresh Over",
                 "Excess Under", "Excess Over"))
    add_report("AUDTEST", "audit_test_array", audit_test_array)
    add_report("AUDTEST", "total", list (sum_y = sum_y,
                                         sum_y_est = sum_y_est,
                                         sum_e = sum_e))
    add_report("AUDTEST", "sum_y", sum_y)
    add_report("AUDTEST", "sum_y_est", sum_y_est)
    add_report("AUDTEST", "sum_e", sum_e)
    add_report("AUDTEST", "excess_count_under", star.env$excess_count_under)
    add_report("AUDTEST", "excess_count_over", star.env$excess_count_over)
    add_report("AUDTEST", "paradox_flag", paradox_flag)
    
    add_report("AUDTEST", "status", "finish")
}