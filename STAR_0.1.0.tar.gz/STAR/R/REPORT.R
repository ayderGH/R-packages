### AUDIT REPORT ###
AUDIT_00 <- "Audit test report"
AUDIT_01 <- "No excesses have been identified by the analytical procedure." 
AUDIT_02 <- "The analytical procedure identified the following Excesses to be investigated:"
AUDIT_03 <- "indicating potential excess under threshold"
AUDIT_04 <- "indicating potential excess over threshold"
AUDIT_05 <- "If the sum of the residuals exceeds performance materiality, consider any of the other excesses that have been identified in the application. Reduce the cumulative residual by the amount of excesses that have been quantified and corroborated in step 1 below. If the remaining cumulative residuals exceeds performance materiality, then seek additional explanations from management and quantify and corroborate the factors."
AUDIT_06 <- "Next Steps:"
AUDIT_07 <- "For each Excess, investigate the residual by:\n 1. Inquiring of management and obtaining appropriate audit evidence relevant to management’s response\n If such investigation does not result in a satisfactory explanation, then the Excess is a substantive analytical procedure misstatement. \n 2. Consider whether there are unusual patterns in the residuals that should be investigated (e.g., residuals tending strongly in one direction close to the individual thresholds, with a total that is multiples of performance materiality).\n 3. disaggregating the data, introducing one or more additional variables (real or dummy), or removing one or more variables that is causing the variability.\n 4. For more information see examples provided in the Performing Substantive Analytical Procedures Guide section x.x Identification of Significant Differences.\n 5. To discuss further alternatives please submit an online support request."

### REGRESSION ###
REGRESS_00 <- "Stepwise multiple regression model"
REGRESS_01 <- 'Variables preceded by "&", indicates a forced variable.'
REGRESS_02 <- "Expectation of test variable"
REGRESS_03 <- "for observation t is:"
REGRESS_04 <- "Coefficient of correlation:"

### STAR HELP ###
HELP_01 <- "The amount or amounts set by the auditor at less than materiality for the financial statements as a whole to reduce to an appropriately low level the probability that the total aggregate of uncorrected and undetected misstatements exceeds materiality for the financial statements as a whole. If applicable, performance materiality also refers to the amount or amounts set by the auditor at less than the materiality level or levels for particular classes of transactions, account balances or disclosures."
HELP_02 <- "The difference between the recorded amount and the regression estimate)."
HELP_03 <- "The threshold represents the maximum difference between an expectation and a recorded amount that is acceptable without further investigation. The threshold is the primary criterion for selecting differences for investigation. The threshold is not a measure of the actual misstatement of the class of transaction, account balance or disclosure, but rather the acceptable amount of uncertainty. The threshold needs to be small enough to identify misstatements that, individually or when aggregated with other misstatements, may cause the financial statements to be materially misstated."
HELP_04 <- "The amount by which a difference exceeds the threshold."

### WARNINGS ###
WARNING_01 <- "Y constant. Cannot model."
WARNING_02 <- "star.env$NO SIGNIFICANT PREDICTING VARIABLE HAS BEEN FOUND.\n  STAR will not process the data further.  Review the base profile and study the relationships analytically to determine why the predicting variable(s) do not have the expected relationships to the test variable."
WARNING_03 <- "Perfect correlation. Cannot use."
WARNING_04 <- "Correlation of 0.9999 is unusually high."
WARNING_05 <- "THERE IS AN INDICATION OF DISCONTINUITY IN THE BASE PROFILE. \n STAR will not process the data further.  Discontinuity is ordinarily caused by a change in conditions which affects the relationship between the variables.  Examine the plot of residuals to identify the cause.  Including an appropriate predicting variable in the model may eliminate the condition." 
WARNING_06 <- "THERE IS AN INDICATION OF DISCONTINUITY BETWEEN BASE AND PROJECTION PROFILES. \n This type of discontinuity does not invalidate the model but it may affect the differences to be audited.  If it is not eliminated, it may result in invalid models in future years.  Examine the plot of residuals to identify the cause."
WARNING_07 <- "ABNORMALITY IN THE BASE PERIOD IS INDICATED BY:"
WARNING_08 <- "LEFT SKEWNESS--This may be caused by large negative residuals"
WARNING_09 <- "RIGHT SKEWNESS--This may be caused by large positive residuals"
WARNING_10 <- "KURTOSIS--This may be caused by both large positive and large negative residuals."
WARNING_11 <- "Abnormality does not invalidate the model but it may affect the differences to be audited.  Examine the plot of the residuals to identify the outliers and, if possible, eliminate the abnormality by correcting any errors or unusual events in those observations."
WARNING_12 <- "THERE IS AN INDICATION OF HETEROSCEDASTICITY IN THE BASE PROFILE. \n Weighted least squares regression will be used to correct for the condition. Heteroscedasticity is evidenced by significant correlation between the size of the residuals and one of the predicting variables, in this case %s."
WARNING_13 <- "The model may be improved by identifying the cause of the heteroscedasticity and introducing appropriate predicting variables.  This may also reduce the differences to be audited."
WARNING_14 <- "The program cannot adjust for heteroscedasticity when the X variable with which the residuals are correlated contains a zero value. In this case %s1 <- 0 in observation %s2 (and possibly in others). \n This model should not be used for audit purposes."
WARNING_15 <- "Weighted regression did not correct for the heteroscedasticity. This model should not be used for audit purposes."
WARNING_16 <- "THERE IS AN INDICATION OF AUTOCORRELATION IN THE BASE PROFILE.  \n Generalized least squares regression will be used to correct for the condition. Autocorrelation can often be attributed to a missing major factor and is evidenced by a pronounced pattern in the residuals.  Examine the plot of residuals to identify the missing factor.  Including that factor as a predicting variable may eliminate the condition and reduce the differences to be audited."
WARNING_17 <- "Fatal Autocorrelation. \n  This model should not be used for audit purposes."


star.env$report_row <- 1


add_report <- function(section, name, value, description = '') {
    star.env$Report[[ star.env$report_row ]] <- list(row_index = star.env$report_row, 
                                                     section = section, 
                                                     name = name, 
                                                     value = value, 
                                                     description = description)
    star.env$report_row <- star.env$report_row + 1
}


add_sh_report <- function(name, value, description = '') {
    star.env$sh_report[[ star.env$sh_report_row ]] <- list(name = name, value = value, description = description)
    star.env$sh_report_row <- star.env$sh_report_row + 1
}


find_report <- function(report, section = NULL, name, idx = 1) {
    cnt <- 1
    for (i in 1:length(star.env$Report)) {
        if ((is.null(section) || section == star.env$Report[[i]]$section) 
            && star.env$Report[[i]]$name == name) 
        {
            if (idx == cnt)
                return(star.env$Report[[i]]$value)
            else
                cnt <- cnt + 1
        }
    }
}


find_audit_test_report <- function(report) {
    aud_table_colnames <- find_report(report, "AUDTEST", "audit_test_array_colnames")
    aud_table <- find_report(report, "AUDTEST", "audit_test_array")
    aud_total <- find_report(report, "AUDTEST", "total")
  
    audit_table <- data.frame (aud_table)
    colnames(audit_table) <- aud_table_colnames
    audit_table <- rbind(audit_table,
                         c("Total", aud_total$sum_y, aud_total$sum_y_est, 
                         aud_total$sum_e, "", "", "", ""))
    return(audit_table)
}


find_residuals <- function (report, idx = 1) {
    res_plot_colnames <- find_report(report, "P_RESPLT", "plot_array_colnames", idx)
    res_plot <- find_report(report, "P_RESPLT", "plot_array", idx)
    
    residual_plot <- data.frame(res_plot)
    colnames(residual_plot) <- res_plot_colnames
    
    return(residual_plot)
}


find_normalized_vars <- function (report) {
    norm_vars_colnames <- find_report(report, "P_NORM_VARS", "normalized_vars_colnames")
    norm_vars <- find_report(report, "P_NORM_VARS", "normalized_vars")
    
    normalized_vars <- data.frame(norm_vars)
    colnames (normalized_vars) <- norm_vars_colnames
    
    return(normalized_vars)
}


find_scatter <- function (report) {
    sctr <- find_report(report, "SCATTR", "scattr")
    num <- find_report(report, "SCATTR", "num_diagrams")
    scatter <- list()
    
    for (i in 1:num) {
        scatter[[i]] <- data.frame(sctr[[i]]$coords)
        colnames(scatter[[i]]) <- c(sctr[[i]]$var1$name, sctr[[i]]$var2$name)
    }
    
    return(scatter)
}


find_observations <- function(report) {
    obs_colnames <- find_report(report, "P_OBS", "obs_colnames")
    obs <- find_report(report, "P_OBS", "observations")
    obs_total <- find_report(report, "P_OBS", "sumx")
    
    observations <- data.frame(obs)
    colnames(observations) <- obs_colnames
    observations <- rbind(observations, c("Total", obs_total))
    
    return (observations)
}


prepare_report <- function(report) {
    star.env$sh_report <- list()
    star.env$sh_report_row <- 1
  
    add_sh_report("message_start", "*** STAR: Statistical Techniques for Analytical Review ***")
  
    for (i in 1:length(star.env$Report)) {
        if (star.env$Report[[i]]$section == "STARCALC"
            && star.env$Report[[i]]$name == "status"
            && star.env$Report[[i]]$value == "finish") 
        {
          starcalc_finish_description <- star.env$Report[[i]]$description
        }
    } 
        
    data_profile <- find_report(report, name = "data_profile")
    projection_type <- find_report(report, name = "projection_type")
    
    # observations
    observations <- find_observations(report)
    
    # test for Y with negligible standard error
    if (starcalc_finish_description == "star.env$sqrt_ss_x[1] < star.env$TOLERANCE") {
        add_sh_report("error", "negligible standard error", WARNING_01)
        add_sh_report("observations", observations, "Listing observations. 
                      Variables Used (+), Not Used (-)")
        return(star.env$sh_report)
    }
    
    # warning if no significant variables
    if (starcalc_finish_description == "variable_count() == 0") {
        add_sh_report("error", "no significant variables", WARNING_02)
        add_sh_report("observations", observations, "Listing observations. 
                      Variables Used (+), Not Used (-)")
        return(star.env$sh_report)
    }
    
    # write coordinates for scatter diagram
    scatter <- find_scatter(report)
    add_sh_report("scatter", scatter, "Coordinates for scatter diagrams")
    
    # write coordinates for plot of normalized vars
    normalized_vars <- find_normalized_vars(report)
    add_sh_report("normalized_vars", normalized_vars, 
                "Coordinates for plot of normalized vars")
    
    # test for perfect correlation
    if (starcalc_finish_description == "correlation_coefficient >= 1.0") {
        add_sh_report("error", "perfect correlation", WARNING_03)
        add_sh_report("observations", observations, "Listing observations. 
                      Variables Used (+), Not Used (-)")
        return(star.env$sh_report)
    }
    
    # write regression function
    add_sh_report("variables_symbols", find_report(report, "P_FUNC", "symbol", 1))
    add_sh_report("coefficients", find_report(report, "P_FUNC", "beta", 1), "Regression constant and coefficients")
    correl_coef <- find_report(report, "P_REGMOD", "correlation_coefficient")
    add_sh_report("correlation_coefficient", correl_coef)
    
    # warning if high correlation
    if (find_report(report, "STARCALC", "warning_high_correlation") == "TRUE")
        add_sh_report("warning", "high correlation", WARNING_04)
    
    # plot of residuals
    residual_plot <- find_residuals(report, 1)
    
    # test for discontinuity in the base period
    if (starcalc_finish_description == "base_discontinuity"){
        add_sh_report("error", "base discontinuity", WARNING_05)
    
    # write plot of residuals
    add_sh_report("residuals", residual_plot, 
                  "Array with information about residuals. Needed to creating plot of residuals")
    # write observations
    add_sh_report("observations", observations, "Listing observations. 
                  Variables Used (+), Not Used (-)")
    return(star.env$sh_report)
    }
    
    # test for discontinuity between the base and projection periods
    if (find_report(report, "STARCALC", "proj_discontinuity") == "TRUE")
        add_sh_report("warning", "discontinuity between the base and projection periods", WARNING_06)
    
    # test for abnormality
    if (correl_coef < 99.99) {
        skewness <- find_report(report, "ABNORM", "skewness")
        kurtosis <- find_report(report, "ABNORM", "kurtosis")
    
        if (skewness | kurtosis) {
            warn <- WARNING_07
            if (skewness == -1)
                warn <- paste (warn, WARNING_08, sep = "\n")
            if (skewness == 1)
                warn <- paste (warn, WARNING_09, sep = "\n")
            if (kurtosis)
                warn <- paste (warn, WARNING_10, sep = "\n")
            warn <- paste (warn, WARNING_11, sep = "\n")
            add_sh_report("warning", "abnormality", warn)
        }
    }
    
    # write plot of residuals
    add_sh_report("residuals", residual_plot, 
                  "Array with information about residuals. Needed to creating plot of residuals")

    # test for heteroscedasticity
    if (correl_coef < 99.99) {
        w_hetero <- find_report (report, "HETERO", "w")
        # FATAL_HETEROSCEDASTICITY
        if (w_hetero != 0) {
            warn <- paste (WARNING_12, WARNING_13, sep = "\n")
          
            if (starcalc_finish_description == "w == -1" || starcalc_finish_description == "w == -2") {
                if (starcalc_finish_description == "w == -1")
                    warn <- paste (warn, WARNING_14, sep = "\n")
                else 
                    warn <- paste (warn, WARNING_15, sep = "\n")
            
                add_sh_report("error", "heteroscedasticity", warn)
            
                # write observations
                add_sh_report("observations", observations, "Listing observations. Variables Used (+), Not Used (-)")
            
                return(star.env$sh_report)
            }
            else 
                add_sh_report("warning", "heteroscedasticity", warn)
        }
    }

    # test for autocorrelation
    if (data_profile == "TIME SERIES" & correl_coef < 99.99) {
        for (i in 1:length(star.env$Report)) {
            if (star.env$Report[[i]]$section == "AUTO"
                && star.env$Report[[i]]$name == "status"
                && star.env$Report[[i]]$value == "finish") 
            {
                auto_finish_description <- star.env$Report[[i]]$description
            }
    } 

    if (auto_finish_description  != "DW_test == 0") {
        warn <- WARNING_16
      
        if (starcalc_finish_description == "p == star.env$FATAL_AUTOCORRELATION") {
            warn <- paste (warn, WARNING_17, sep = "\n")
        
            add_sh_report("error", "autocorrelation", warn)
        
            # write observations
            add_sh_report("observations", observations, "Listing observations. Variables Used (+), Not Used (-)")
        
            return(star.env$sh_report)
        }
        else
            add_sh_report("warning", "autocorrelation", warn)
        }
    }
    
    w_main <- find_report(report, "STARCALC", "w")
    p_main <- find_report(report, "STARCALC", "p")
    
    if (w_main > 0 | p_main > 0) {
        add_sh_report("variables_symbols", find_report(report, "P_FUNC", "symbol", 2))
        add_sh_report("coefficients", find_report(report, "P_FUNC", "beta", 2), "New regression constant and coefficients")
        add_sh_report("std_error", find_report(report, "P_FUNC", "std_err_beta[0]"))
        
        # plot of residuals
        residual_plot <- find_residuals(report, 2)
        
        add_sh_report("residuals", residual_plot, 
                      "Array with information about NEW residuals. Needed to creating plot of residuals")
    }
        
    # skip audit / ending balance projection if no projection data
    if (projection_type != "NONE") {
        # audit / ending balance / regression
        if (projection_type == "star.env$AUDIT")
            write_audit_report(report)
        else if (projection_type == "ENDING BALANCE") 
            write_end_bal_report(report)
        else if (projection_type == "star.env$REGRESSION")
            write_regression_report(report)
    }
    
    # write observations
    add_sh_report("observations", observations, "Listing observations. Variables Used (+), Not Used (-)")

    return(star.env$sh_report)
}


# Audit test report
write_audit_report <- function (report){
    mp <- find_report (report, "AUDTEST", "mp_entered")
    excess_count_under <- find_report (report, "AUDTEST",  "excess_count_under")
    excess_count_over <- find_report (report, "AUDTEST",  "excess_count_over")
    
    audit_table <- find_audit_test_report(report)
    
    # write audit test results table
    add_sh_report("audit", audit_table, "Audit test results")
    
    
    if (excess_count_under + excess_count_over == 0)
        rep <- AUDIT_01
    else { 
        rep <- AUDIT_02
    
    if (excess_count_under != 0)
        rep <- paste (rep, paste (excess_count_under, AUDIT_03), sep = "\n")
    if (excess_count_over != 0)
        rep <- paste (rep, paste (excess_count_over, AUDIT_04), sep = "\n")
    }
    
    rep <- paste(rep, AUDIT_05, AUDIT_06, AUDIT_07, sep = "\n")
    add_sh_report("audit", "message", rep)
}


write_end_bal_report <- function (report){}


write_regression_report <- function (report){}