# ***************************************************************************
#     PROJ.R
# ****************************************************************************

#' Project value of Y.
#' This is done by using the residual () functiion to calculate the residual
#' and then subtracting that residual from the recorded Y value.
projection <- function(i, w, p) {
    # get the reorded Y value
    py <- get_x(i, 0)
    
    # calculate the residual
    pe <- residual(i, w, p)
    
    # if the function is heteroscedastic multiply the residual by the X used to weight the function
    if (w > 0) {
        pe <- get_x(i, w)
    }
    
    # finally, the projected value = recorded - residual
    py_est <- py - pe
    
    return(list(y = py, y_est = py_est, e = pe))
}
