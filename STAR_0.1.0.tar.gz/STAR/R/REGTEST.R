#' ***************************************************************************
#' regtest.c 8/14/88 9:30
#' ****************************************************************************
#' Confidence interval calculations for the projection period.
#' 
#' Each observation in the projection period is compared with a confidence
#' interval.
#' ***************************************************************************
RegressionTest <- function(w, p) {
    y <- as.double()             # recorded y value
    e <- as.double()             # residual
    precision <- as.double()     # confidence bound
    y_est <- as.double()         # regression estimate of y
    se_res <- as.double()        # standard error of the residual
    excess <- as.double()        # excess to be investigated
    least_excess <- as.double()  # smallest excess to be investigated
    sum_y <- as.double()         # sum of the recorded y's
    sum_e <- as.double()         # sum of the residuals
    sum_y_est <- as.double()     # sum of the estimated y's
    t <- as.double()             # t value for confidence
    ndec <- as.integer()         # number of decimals for y
    
    # DisplayStatus (GetStrTblEntry(  REGTEST_0  ));
    ndec <- star.env$variable$decimals[1]

    # Initialize constants and accumulators
    sum_y <- sum_e <- sum_y_est <- 0.0

    # we will not display excesses smaller than least sig digit
    least_excess <- 10.0^-ndec

    # Calculate std error inverse matrix
    invert_matrix()
    
    add_report("REGTEST", "conf_level", star.env$conf_level)

    # cut-off t value
    t <- -t_value((1 - star.env$conf_level) / 2.0, star.env$df)

    # This next line seems silly, but it initializes the previous residual
    # (to the last base period). It is needed in case of autocorrelation.
    # If this is not done the last base period residual (a static
    # double in residual() ) may not be correct in certain circumstances
    # (eg, if the residuals have just been plotted)
    
    proj <- projection(ifelse(star.env$n_first_proj > 0, star.env$n_first_proj - 1, 0), w, p)
    y <- proj$y
    y_est <- proj$y_est
    e <- proj$e

    # Main loop begins here with input from projection profile
    for (i in star.env$n_first_proj:star.env$n_last_proj) {
        # get y, and calculate y_est, e
        proj <- projection(i, w, p)
        y <- proj$y
        y_est <- proj$y_est
        e <- proj$e

        # Calculate standard error of projection
        se_res <- standard_error(i, w, p)
        precision <- t * se_res
        
        excess <- 0.0
        if (abs(e) > precision + least_excess)
            excess <- ifelse(e < 0, e + precision, e - precision)

        # Print projection results
        add_report("REGTEST", "i", i+1)
        add_report("REGTEST", "y", y)
        add_report("REGTEST", "y_est", y_est)
        add_report("REGTEST", "e", e)
        add_report("REGTEST", "se_res", se_res)
        add_report("REGTEST", "precision", precision)
         
        # excess and related data, if any
        if (excess)
        {
            # excess
            add_report("REGTEST", "excess", excess)
        }

        # Accumulate totals
        sum_y <- sum_y + round(y, ndec)
        sum_y_est <- sum_y_est + round(y_est, ndec)
        sum_e <- sum_e + round(e, ndec)
    }

    # Print totals
    
    # Print single underlines
    add_report("REGTEST", "sum_y", sum_y)
    add_report("REGTEST", "sum_y_est", sum_y_est) 
    add_report("REGTEST", "sum_e", sum_e) 
    
    # print double underlines
    add_report("REGTEST", "t", t)
    add_report("REGTEST", "conf_level", star.env$conf_level)
}
