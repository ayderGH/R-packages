#***************************************************************************
# INV_MAT.R
#****************************************************************************

#' Compute the inverse matrix for standard error calculations. In
#' this calculation x_x[i][j] starts off by containing the inverse of
#' the correlation matrix. It ends by containing the required matrix
#'   
#' See Stringer & Stewart p 234 for details
invert_matrix <- function() {
  
    add_report("INV_MAT", "status", "start")
  
    # divide element (i,j) of matrix by (sqrt_ss_x[i] * sqrt_ss_x[j]) -- Stringer and Stewart p 234
    for (i in 1:star.env$k) {
        for (j in 1:star.env$k) {
            if (star.env$beta[i+1] == 0.0 | star.env$beta[j+1] == 0.0)
                star.env$x_x[i+1, j+1] <- 0.0
            if (star.env$sqrt_ss_x[i+1] > 0.0 & star.env$sqrt_ss_x[j+1] > 0.0)
                star.env$x_x[i+1, j+1] <- star.env$x_x[i+1, j+1] / (star.env$sqrt_ss_x[i+1] * star.env$sqrt_ss_x[j+1])
        }
    }
    # set unneeded elements to zero (variables not in the regression)
    for (i in 0:star.env$k) {
        star.env$x_x[i+1, 1] <- 0.0
        star.env$x_x[1, i+1] <- 0.0
    }
  
    # print matrix
    add_report("INV_MAT", "invert_matrix_colnames", star.env$variable$symbol)
    add_report("INV_MAT", "invert_matrix_rownames", star.env$variable$symbol)
    add_report("INV_MAT", "invert_matrix",
               value = array(star.env$x_x, dim = dim(star.env$x_x), 
                             dimnames = list(star.env$variable$symbol, star.env$variable$symbol)))
  
    add_report("INV_MAT", "status", "finish")
}
