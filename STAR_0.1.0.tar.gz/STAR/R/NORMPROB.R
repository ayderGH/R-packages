# *************************************************************************
# NormProb.R
# *************************************************************************

#' Returns the area under the normal probability curve to the left of z
#' Algorithm from Abramowitz & Stegun (1972), p.932, 26.2.16 
NormProb <- function(z) {
    if (z == 0)
    {
        return(0.5)
    }
    
    q <- 1.0 / (1 + star.env$C_A0 * abs(z))
    q <- 1.0 - exp (-z * z / 2) / sqrt(2*pi) * (star.env$C_A1*q + star.env$C_A2*q*q + star.env$C_A3*q*q*q)
    
    return(ifelse(z > 0, q, 1 - q))
}