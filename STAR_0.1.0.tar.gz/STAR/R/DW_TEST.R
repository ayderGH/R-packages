# ****************************************************************************
# DW_test.R
# *****************************************************************************

#' Perform the Durbin-Watson test for autocorrelation. Stringer & Stewart s 8.4
#' Return 1 if residuals autocorrelated, else 0.
#' 
#' The program first calculates the Durbin-Watson test statistic d.  The exact
#' distribution of this is not known, but is approximated by the distribution
#' of d_U.  The tail probability of d_U is compared with the significance level
#' set for the test.  If it is less than that significance level then
#' autocorrelation is significant at that level. DW_prob() yields the tail prob.
DW_test <- function(w, p) {
    f <- as.double()                        # residual
    f_1 <- as.double()                      # previous residual
    sum_squared_residuals <- as.double()    # sum of the f-squares
    sum_squared_differences <- as.double()  # sum of the (f - f_1) squares
    d <- as.double()                        # Durbin-Watson test statistic
    d_U_prob <- as.double()                 # Tail probability for d_U distributed statistic
    k_in <- as.integer()                    # number of independent variable in regression
    n <- as.integer()                       # number of observations in base
    
    add_report("DW_TEST", "status", "start")
    
    # calculation for first observation
    f_1 <- residual (star.env$n_first_base, w, p)
    sum_squared_residuals <- f_1 * f_1
    sum_squared_differences <- 0
    
    # calculations for second and subsequent observations
    for (i in (star.env$n_first_base + 1):(star.env$n_last_base)){
        f <- residual (i, w, p)
        sum_squared_residuals <- sum_squared_residuals + f * f
        sum_squared_differences <- sum_squared_differences + (f - f_1) * (f - f_1)
        f_1 <- f  # set previous residual for next loop
    }
  
    # Durbin-Watson test statistic -- Stringer & Stewart page 174, 181, 183
    d <- sum_squared_differences  / sum_squared_residuals
    
    # Get tail probability for d_U distributed statistic d
    k_in <- variable_count()
    n <- star.env$n_last_base - star.env$n_first_base + 1
    d_U_prob <- DW_prob (d, k_in, n)
    
    # print
    add_report("DW_TEST", "sum_squared_differences", sum_squared_differences)
    add_report("DW_TEST", "sum_squared_residuals", sum_squared_residuals)
    add_report("DW_TEST", "d", d)
    add_report("DW_TEST", "k_in", k_in)
    add_report("DW_TEST", "n", n)
    add_report("DW_TEST", "d_U_prob", d_U_prob*100)
    add_report("DW_TEST", "star.env$SIGLEV_AUTO", star.env$SIGLEV_AUTO*100)
    
    add_report("DW_TEST", "status", "finish")
    
    # autocorrelation is significant if d_U_prob is less than star.env$SIGLEV_AUTO
    return(ifelse(d_U_prob < star.env$SIGLEV_AUTO, 1, 0))
}