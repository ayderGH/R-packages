#' Adapted from "Ftest", Algorithm 346 in "Collected Algorithms from ACM"
#'
#' Calculate the probability integral
#' P (x > F  | df1, df2)
#' This is the area under the F-distribution to the right of F.
#'
#' . .
#' .     .
#' .       .
#' .         .
#' .            .
#' .                .
#' .     P (x>F) -->  x x .
#' .                    x x x x .
#' ------------------------|---------
#' F
#'
#' The function has the following parameters:
#' F              = input F value
#' df1            = degrees of freedom, numerator
#' df2            = degrees of freedom, denominator
#'
#' An approximation is included to limit execution time when df1+df2 > MAXN.
#' According to the CACM description of the algorithm, the approximation
#' is accurate to 3 decimals when MAXN = 500.  This seems a reasonable value.
F_test <- function(F, df1, df2) {
    v1 <- v2 <- x <- ftail <- vp <- as.double()

    if (F == 0)
        return(1)

    v1 <- as.double(df1)
    v2 <- as.double(df2)
    ftail <- 0

    x <- v2 / (v2 + v1 * F)
    vp <- v1 + v2 - 2

    if ( (df1 %% 2  ==  0)   &   (df1  <=  star.env$MAXN) ){
        xx <- as.double(1 - x)
        v1 <- v1 - 2
        while (v1 > 1){
            vp <- vp - 2
            ftail  <-  xx  *  vp / v1  *  (1 + ftail)
            v1 <- v1 - 2
        }
        ftail <- x^(0.5 * v2) * (1 + ftail)
    }
    else{
        if ( (df2 %% 2  ==  0)   &   (df2  <=  star.env$MAXN) ){
            v2 <- v2 - 2
            while (v2 > 1){
                vp <- vp - 2
                ftail  <-  x  *  vp / v2  *  (1 + ftail)
                v2 <- v2 - 2
            }
            ftail <- 1 - (1 - x)^(0.5 * v1) * (1 + ftail)
        }
        else{
            if (df1 + df2  <=  star.env$MAXN){
                theta <- sth <- cth <- sts <- cts <- as.double()
                a <- b <- xi <- gamma <- as.double()

                theta <- atan (sqrt (v1  *  F / v2))
                sth <- sin (theta)
                cth <- cos (theta)
                sts <- sth * sth
                cts <- cth * cth
                a <- b <- 0
                if (df2 > 1){
                    v2 <- v2 - 2
                    while (v2 > 2){
                        a <- cts  *  (v2 - 1) / v2 * (1 + a)
                        v2 <- v2 - 2
                    }
                    a <- sth * cth * (1 + a)
                }
                a <- theta + a
                if (df1  >  1){
                    v1 <- v1 - 2
                    while (v1 > 2){
                        vp <- vp - 2
                        b  <-  sts  *  vp / v1  *  (1 + b)
                        v1 <- v1 - 2
                    }
                    gamma <- 1
                    v2 <- 0.5 * df2
                    for (xi in 1:v2)
                        gamma <- gamma * (xi / (xi - 0.5))
                    b <- gamma * sth * cth^df2 * (1 + b)
                }
                ftail  <-  1  +  2/pi * (b - a)
            }
            else{
              cbrf <- as.double()

              v1 <- 2.0 / (9.0 * v1)
              v2 <- 2.0 / (9.0 * v2)
              cbrf <- F ^ 0.333333333333333333
              ftail <- NormProb( -( (1 - v2) * cbrf + v1 - 1) / sqrt (v2 * cbrf * cbrf + v1))
            }
        }
    }

    return(ifelse(ftail < 0, 0, ftail))
}




