star.env <- new.env()

star.env$MAXN <- 500

#-----------------------GLOBAL CONSTANTS---------------------------------
# All constants are in the capital letters
#
# Exit Codes
star.env$OK <- 0
star.env$BAD_APPLICATION <- 1

# maximum number of columns
star.env$MAX_COLS <- 26  # maximum number of variables allowed, numbered 0 --> 24

# general purpose flag values
star.env$ON <- 1
star.env$OFF <- 0
star.env$YES <- 1
star.env$NO <- 0

# significance levels used in statistical tests (set as matter of policy)
star.env$SIGLEV_ADMIT <- 0.05
star.env$SIGLEV_ELIM <- 0.05
star.env$SIGLEV_DISC_BASE <- 0.01
star.env$SIGLEV_DISC_PROJ <- 0.01
star.env$SIGLEV_ABNORM <- 0.01
star.env$SIGLEV_HETERO <- 0.01
star.env$SIGLEV_AUTO <- 0.01

# Tolerance used in regression and other algorithms
star.env$TOLERANCE <- 0.000001

# Constants _Ai and _Ci are needed for probability functions
star.env$C_A0 <- 0.33267
star.env$C_A1 <- 0.4361836
star.env$C_A2 <- -0.1201676
star.env$C_A3 <- 0.937298

star.env$C_C0 <- 2.515517
star.env$C_C1 <- 0.802853
star.env$C_C2 <- 0.010328
star.env$C_D1 <- 1.432788
star.env$C_D2 <- 0.189269
star.env$C_D3 <- 0.001308

# type of data profile
star.env$TIME_SERIES <- "T"
star.env$CROSS_SECTIONAL <- "C"

# Conditions
star.env$FATAL_AUTOCORRELATION <- -1.0
star.env$FATAL_HETEROSCEDASTICITY <- -1

# projection types
star.env$NO_PROJECTION <- "N"
star.env$AUDIT <- "A"
star.env$END_BAL <- "E"
star.env$REGRESSION <- "R"


# ending balance types
star.env$ASSET <- 'A'
star.env$LIABILITY <- 'L'


# type of account component being projected in ending balance projection
star.env$DEBIT <- 'D'
star.env$CREDIT <- 'C'


# sqrt (2 * PI)
star.env$SQRT_2_PI <- 2.50662827463100157


#-----------------------GLOBAL VARIABLES---------------------------------
# All globals variables begin from ``
#
star.env$z <- as.matrix(NA)                       # observations
star.env$total_n <- as.integer()                  # conceptual number of observations
star.env$real_k <- as.integer()                   # number of real independent variables
star.env$real_k_plus1 <- as.integer()             # number of real variables (real_k + 1)

star.env$account_type <- as.integer()             # star.env$ASSET or star.env$LIABILITY, for ending balance projection
star.env$app_type <- as.integer()                 # star.env$TIME_SERIES or star.env$CROSS_SECTIONAL
star.env$projection_type <- as.integer()          # star.env$AUDIT, star.env$END_BAL, star.env$REGRESSION or star.env$NO_PROJECTION
star.env$bal_name <- as.character()               # name of ending balance
star.env$component_type <- as.integer()           # star.env$DEBIT or star.env$CREDIT, for ending balance projection
star.env$correlation_coefficient <- as.double()   # coefficient of correlation
star.env$direction <- as.integer()                # direction of test, OVERSTATEMENT or UNDERSTATEMENT
star.env$df <- as.integer()                       # degrees of freedom
star.env$ExitCode <- as.integer()                 # exit code
star.env$k <- as.integer()                        # number of independent variables specified
star.env$mp <- as.double()                        # monetary precision adjusted value
star.env$mp_entered <- as.double()                # monetary precision as entered by user
star.env$n_first_base <- as.integer()             # first observation in base profile
star.env$n_last_base <- as.integer()              # last observation in base profile
star.env$n_first_proj <- as.integer()             # first observation in projection profile
star.env$n_last_proj <- as.integer()              # last observation in projection profile
star.env$periods_per_year <- as.integer()         # number of periods per year (commonly 12)
star.env$rec_bal <- as.double()                   # recorded balance, for ending balance projection
star.env$r_factor <- as.double()                  # reliability factor for audit and ending balance projections
star.env$conf_level <- as.double()                # confidence level for regression projections
star.env$seas_adj <- as.integer()                 # seasonal adjustment flag (on/off)
star.env$trend_adj <- as.integer()                # trend adjustment flag (on/off)
star.env$show_r <- as.integer()                   # flag to show R factor (1) or suppress (0)
star.env$sse <- as.double()                       # error (regression) sum of squares
star.env$STARversion <- as.character()            # software version number
star.env$testinstrategy <- as.character()      # description of testing strategy associated with R-Factor
star.env$applicable_risk_Level <- as.character()  # The applicable risk level chosen by the user

star.env$beta <- as.array(NA)                     # regression coefficients, beta[0] is regression constant
star.env$force_x <- as.array(NA)                  # flag to force an X varianle
star.env$lag <- as.array(NA)                      # number of lag periods
star.env$original_xbar <- as.array(NA)            # array to save original means of variables
star.env$row <- as.array(NA)                      # array for holding row of observations
star.env$sqrt_ss_x <- as.array(NA)                # square root of sum of squared deviations from the mean
star.env$std_err_beta <- as.array(NA)             # standard errors of regression coefficients
star.env$xbar <- as.array(NA)                     # means
star.env$x_x <- as.matrix(NA)                     # matrix for regression computations -- starts off as correlation matrix


# Result Table
star.env$Report <- list()


# structure containing data about variables specified for model
star.env$variable <- data.frame(source = as.character(),
                           pf_formula = as.character(),
                           symbol = as.character(),
                           name = as.character(),
                           units = as.character(),
                           bypass_thru = as.integer(),
                           bypass_from = as.integer(),
                           decimals = as.integer())

# structure containing data about variables in data file
star.env$var_defn <- data.frame(source = as.character(),
                           pf_formula = as.character(),
                           symbol = as.character(),
                           name = as.character(),
                           units = as.character(),
                           bypass_thru = as.integer(),
                           bypass_from = as.integer(),
                           decimals = as.integer())


# STATIC variables of functions

# RESIDUAL.R
# residual()
star.env$e_1 <- 0 #as.double()  # residual for period t-1

# AUDTEST.R
# audtest()
# flags indicating at least one excess_under or excess_over
star.env$excess_count_under <- as.integer()
star.env$excess_count_over <- as.integer()
