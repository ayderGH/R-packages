#' Get the i-th row of observations and put them in the array x[].
#' Assume the observation matrix is z[][]. But this is arbitrary.
#'  
#' If w > 0 then weight the observations by x[w].
#'  
#' If p > 0 then take the first differences of the (weighted) observations.
#'  
#' This routine hides the observations from the rest of STAR; i.e., the
#' rest of the program does not care how the observations are stored or accessed.
#'  
#' If weight = 0 then set it = 1. NOTE CHANGE FROM BASIC STAR WHERE FATAL ERROR
get_row <- function(x, i, w, p) {
    
    x_prev <- array(0, dim = star.env$MAX_COLS)
    weight <- as.double()
    
    # get row from data store
    for (j in 0:star.env$k)
        x[j+1] <- get_x(i, j)
  
    # no weighting, no autocorrelation adjustment
    if (w == 0 & p <= 0.0)
        return(x)
  
    # weight the row using x[w]
    if (w > 0) {
        weight <- x[w+1]
        if (weight == 0.0) {
            weight <- 1.0
        }

        for (j in 0:star.env$k) {
            x[j+1] <- x[j+1] / weight
        }
        
        x[w+1] <- 1.0 / weight
    }
  
    # autocorrelation adjustment required
    if (p > 0.0) {
        if (i == star.env$n_first_base) {
            # for first row only
            for (j in 0:star.env$k) {
                x[j+1] <- x[j+1] * sqrt(1.0 - p*p)
            }
        }
        
        # for second and subsequent rows
        else {
            # get previous row. weight but don't adjust for auto
            x_prev <- get_row(x_prev, i-1, w, 0.0)
            for (j in 0:star.env$k) {
                x[j+1] <- x[j+1] - p * x_prev[j+1]
            }
        }
    }
    
    return(x)
}