# ****************************************************************************
# DW_prob.R
# *****************************************************************************

#' Calculate the tail probability for the upper-limit Durbin-Watson statistic
#' with k_in and n degrees of freedom where
#' k_in = number of independent variables used
#' n    = number of observations
#'
#' d_U is first transformed into a random variable distributed as F with v1 and v2
#' degrees of freedom where
#' v1 = n - k1 + 2
#' v2 = n + k1
#' and k1 = k_in + 1
#'
#' The program returns
#' P (x > F  | v1, v2)  =  P (d < d_U  | k_in, n)
#'
#' The calculation calls F_test (F, v1, v2) for the area under the F distribution
#' to the right of F.
#'
#' See Stringer & Stewart Tables A.5 and A.6, pages 241-243
DW_prob <- function(d_U, k_in, n) {
    
    v1 <- v2 <- as.double()  # Degrees of freedom for F distribution, v1 = numerator, v2 = denominator
    F <- as.double()         # F value equivalent to d_U
    k1 <-  as.double()       # Total number of variables (independent plus 1)
     
    # initialize 
    k1 <- as.double(k_in + 1)
    
    v1 <- as.double(n - k1 + 2)
    v2 <- as.double(n + k1)
    
    # transform d_U to F value
    F <- ((4 * n * n - 4 * k1 * k1 - 2) * v2 
          / ((d_U * n * n - 4 * k1 * k1 + 1) * v1) 
          - v2 / v1)
    
    # return P (x > F | v1, v2) 
    return (F_test (F, as.integer(v1), as.integer(v2)) )
}