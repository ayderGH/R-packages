# ****************************************************************************
# rho.R
# *****************************************************************************

#' Calculate rho for an autocorrelated function.
#' See Stringer & Stewart p 173 for formula.
rho <- function(w, p) {
    i <- as.integer()               # loop variable
    e <- as.double()                # residual, period i
    e_1 <- as.double()              # residual, period i-1
    sum_cross_products <- 0         # sum cross products e * e_1
    sum_squared_residuals  <-  0    # sum of squares e * e
    
    e_1 <- residual (star.env$n_first_base, w, 0)
    
    # Note that this loop starts with the second observation
    for (i in (star.env$n_first_base + 1):star.env$n_last_base){
        e <- residual (i, w, 0.0)
        sum_cross_products <- sum_cross_products + e * e_1
        sum_squared_residuals <- sum_squared_residuals + e * e
        e_1 <- e
    }
    
    # In unlikely but possible event that sum of cross products exceeds
    # sum of squared residuals, use the last value of rho 
    if (sum_cross_products >= sum_squared_residuals) {
        return (p)
    }
    
    # Stringer & Stewart p 173 
    p <- sum_cross_products /  sum_squared_residuals
    
    # Limit rho to 0.9 
    p <- min (p, 0.9)
    
    # print rho and formula for calculating it 
    add_report("RHO", "sum_cross_products", sum_cross_products)
    add_report("RHO", "p", p)
    
    return (p) 
}