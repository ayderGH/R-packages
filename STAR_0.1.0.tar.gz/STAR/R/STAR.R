prepare_data <- function(data, params) {

    # Transfer all data to numeric format
    for (i in 1:ncol(data)) {
        data[[i]] <- as.numeric(data[[i]])
    }

    y_name <- as.character(params$Y)
    x_names <- names(data)[!(names(data) %in% y_name)]

    star.env$app_type <- switch(as.character(params$app_type),
                                TIME_SERIES = star.env$TIME_SERIES,
                                CROSS_SECTIONAL = star.env$CROSS_SECTIONAL)

    star.env$projection_type <- switch(as.character(params$projection_type),
                                       NO_PROJECTION = star.env$NO_PROJECTION,
                                       AUDIT = star.env$AUDIT,
                                       END_BAL = star.env$END_BAL,
                                       REGRESSION = star.env$REGRESSION)
    star.env$k <<- length(x_names)
    star.env$mp <<- as.double(params$mp)
    star.env$mp_entered <- star.env$mp
    star.env$n_first_base <- as.integer(params$n_first_base) - 1
    star.env$n_last_proj <- as.integer(params$n_last_proj) - 1
    star.env$n_proj_obs <- as.integer(params$n_proj_obs)
    star.env$n_last_base <- star.env$n_last_proj - star.env$n_proj_obs
    star.env$n_first_proj <- star.env$n_last_base + 1

    star.env$last_observation <- max(star.env$n_last_proj, star.env$n_last_base)

    star.env$periods_per_year <- ifelse(is.na(as.integer(params$periods_per_year)), 0, as.integer(params$periods_per_year))
    star.env$seas_adj <- ifelse((params$seas_adj == "YES"), 1, 0)
    star.env$trend_adj <- ifelse((params$trend_adj== "YES"), 1, 0)
    star.env$testing_strategy <- as.character(params$testing_strategy)
    star.env$applicable_risk_Level <- "Significant / Higher / Lower"
    star.env$bal_name <- as.character(params$bal_name)
    star.env$rec_bal <- as.double(params$rec_bal)

    star.env$account_type <- switch(as.character(params$account_type),
                                    ASSET = star.env$ASSET,
                                    LIABILITY = star.env$LIABILITY)

    star.env$component_type <- switch(as.character(params$component_type),
                                      DEBIT = star.env$DEBIT,
                                      CREDIT = star.env$CREDIT)

    star.env$conf_level <- as.double(params$conf_level)

    star.env$z <- data[, c(y_name, x_names)]

    force_names <- as.array(params$force_x)
    star.env$force_x <- array(0, dim = dim(data)[2])
    star.env$force_x[match(force_names, names(data))] <- 1

    star.env$r_factor <- switch(star.env$testing_strategy,
                                "Significant Risk, Relying on Controls" = 1.2,
                                "Higher Risk, Relying on Controls" = 0.5,
                                "Higher Risk, NOT Relying on Controls" = 1.5,
                                "Lower Risk, Relying on Controls" = 0.2,
                                "Lower Risk, NOT Relying on Controls" = 1)

    for (j in 1:(star.env$k+1)) {
        if (j>1)
            if (star.env$force_x[j])
                symbol <- paste ("&X", (j-1), sep = "")
            else
                symbol <- paste ("X", (j-1), sep = "")
            else
                symbol <- paste ("Y")

            star.env$variable <- rbind (star.env$variable, data.frame(source = "",
                                                           pf_formula = "",
                                                           symbol = symbol,
                                                           name = names(star.env$z)[j],
                                                           units = "",
                                                           bypass_thru = "",
                                                           bypass_from = "",
                                                           decimals = 4.0))
    }


    if (star.env$trend_adj) {
        star.env$variable <- rbind (star.env$variable, data.frame(source = "",
                                                       pf_formula = "",
                                                       symbol = paste0("X",(star.env$k+1)),
                                                       name = "Trend",
                                                       units = "",
                                                       bypass_thru = "",
                                                       bypass_from = "",
                                                       decimals = 0))
        star.env$z[paste0("X",(star.env$k))] <- c(1:(star.env$last_observation+1))
        star.env$force_x[star.env$k + 2] <- 0
        star.env$k <- star.env$k + 1

    }

    if (star.env$seas_adj &
        star.env$app_type == star.env$TIME_SERIES &
        star.env$periods_per_year != 0 &
        (star.env$n_last_base - star.env$n_first_base + 1) / star.env$periods_per_year >= 3 &
        star.env$k + star.env$periods_per_year < star.env$MAX_COLS)
    {
        star.env$seas_adj <- star.env$YES
    }
    else {
        star.env$seas_adj <- star.env$NO
    }

    if (star.env$seas_adj) {
        cnt <- 1
        for (j in (star.env$k + 1):(star.env$k + star.env$periods_per_year)) {
            star.env$variable <- rbind(star.env$variable, data.frame(source = "",
                                                          pf_formula = "",
                                                          symbol = paste0("S",(j-star.env$k)),
                                                          name = paste("Seasonal",(j-star.env$k)),
                                                          units = "",
                                                          bypass_thru = "",
                                                          bypass_from = "",
                                                          decimals = 0))
            seascol <- rep (0, star.env$last_observation+1)
            q <- cnt
            while (q <= star.env$last_observation+1) {
                seascol[q] <- 1
                q <- q + star.env$periods_per_year
            }

            star.env$z[paste0("S",(j-star.env$k))] <- seascol
            cnt <- cnt + 1
        }
        star.env$force_x[(star.env$k + 2):(star.env$k + 1 + star.env$periods_per_year)] <- 0
        star.env$k <- star.env$k + star.env$periods_per_year
    }

    star.env$real_k <- star.env$k
}


star <- function() {

    add_report("STARCALC", "status", "start")

    w <- as.integer()  # number of variable used weighted least squares
    p <- as.double()   # coefficient of autocorrelation
    j <- as.integer()  # loop variables
    n1 <- n2 <- as.integer()  # first, last observations used

    # initialization
    star.env$ExitCode <- star.env$OK
    w <- 0
    p <- 0.0

    n1 <- star.env$n_first_base
    if (star.env$n_first_proj > -1) {
        n1 <- min(star.env$n_first_base, star.env$n_first_proj)
    }
    n2 <- max(star.env$n_last_base, star.env$n_last_proj)

    # print the model specs
    P_ModSpc()

    #scatter diagram
    scattr()

    P_Normalized_vars()
    # create correlation matrix and calc related stats
    correlate(star.env$n_first_base, star.env$n_last_base, w, p)

    # test for Y with negligible standard error
    if (star.env$sqrt_ss_x[1] < star.env$TOLERANCE)
    {
        P_Obs(n1, n2)
        add_report("STARCALC", "status", "finish", "star.env$sqrt_ss_x[1] < star.env$TOLERANCE")
        return()
    }

    # save the original means for later
    for (j in 0:star.env$k) {
        star.env$original_xbar[j+1] <- star.env$xbar[j+1]
    }

    # print correlation matrix */
    add_report("STARCALC", "correlation_matrix_colnames", star.env$variable$symbol)
    add_report("STARCALC", "correlation_matrix_rownames", star.env$variable$symbol)
    add_report("STARCALC", "correlation_matrix",
               value = array(star.env$x_x, dim = dim(star.env$x_x),
                             dimnames = list(star.env$variable$symbol, star.env$variable$symbol)))

    # do regression
    regress()

    if (star.env$ExitCode)
    {
        add_report("STARCALC", "status", "finish")
        return()
    }

    calc_function()

    # warning if no significant variables
    if (variable_count() == 0)
    {
        P_Obs(n1, n2)
        add_report("STARCALC", "status", "finish", "variable_count() == 0")
        return()
    }

    # test for perfect correlation
    if (star.env$correlation_coefficient >= 1.0)
    {
        P_Obs(n1, n2)
        add_report("STARCALC", "status", "finish", "correlation_coefficient >= 1.0")
        return()
    }

    star.env$correlation_coefficient <- min(star.env$correlation_coefficient, 0.9999)

    # print regression model
    P_RegMod()

    # print regression function
    P_Func(0, 0.0)

    # warning messssage if suspiciously high correlation
    if (star.env$correlation_coefficient >= 0.9999)
        add_report("STARCALC", "warning_high_correlation", "TRUE")
    else
        add_report("STARCALC", "warning_high_correlation", "FALSE")
    # test for discontinuity in the base -- skip if cross-sectional, base too small, or correlation >= 95%
    if (star.env$app_type == star.env$TIME_SERIES
        & star.env$n_last_base - star.env$n_first_base + 1 - star.env$periods_per_year >= 3
        & star.env$correlation_coefficient < 0.95)
    {
        if (base_discontinuity())
        {
            P_ResPlt(n1, n2, 0, 0.0)
            P_Obs(n1, n2)
            add_report("STARCALC", "status", "finish", "base_discontinuity")
            return()
        }
    }

    # test for discontinuity between the base and projection periods
    if (proj_discontinuity())
        add_report("STARCALC", "proj_discontinuity", "TRUE")
    else
        add_report("STARCALC", "proj_discontinuity", "FALSE")

    # test for abnormality
    if (star.env$correlation_coefficient < 0.9999) {
        abnormality()
    }

    # plot the residuals
    P_ResPlt(n1, n2, w, p)

    # test for heteroscedasticity
    if (star.env$correlation_coefficient < 0.9999)
    {
        w <- hetero()

         if (w == star.env$FATAL_HETEROSCEDASTICITY | w == star.env$FATAL_HETEROSCEDASTICITY - 1)
        {
            P_Obs(n1, n2)
            # if (ReportOption.Scatter)
            #     scattr ()
            add_report("STARCALC", "status", "finish", paste0("w == ", w))
            return()
        }
    }

    if (star.env$ExitCode){
        add_report("STARCALC", "status", "finish")
        return()
    }

    # test for autocorrelation
    if (star.env$app_type == star.env$TIME_SERIES & star.env$correlation_coefficient < 0.9999)
    {
        p <- autocorrelation(w)
        if (p == star.env$FATAL_AUTOCORRELATION)
        {
            P_Obs(n1, n2)
            # if (ReportOption.Scatter)
            #     scattr ()
            add_report("STARCALC", "status", "finish", "p == star.env$FATAL_AUTOCORRELATION")
            return()
         }
    }

    # print final function and the residuals if function has changed
    if (w > 0 | p > 0.0)
    {
        P_Func(w, p)
        P_ResPlt(n1, n2, w, p)
    }

    add_report("STARCALC", "w", w)
    add_report("STARCALC", "p", p)

    star.env$w <- w
    star.env$p <- p

    # skip audit / ending balance projection if no projection data
    if (star.env$projection_type != star.env$NO_PROJECTION & star.env$n_first_proj > -1)
    {
        # audit / ending balance / regression
        if (star.env$projection_type == star.env$AUDIT)
            AuditTest(w, p)
        else if (star.env$projection_type == star.env$END_BAL)
            EndbalTest(w, p)
        else if (star.env$projection_type == star.env$REGRESSION)
            RegressionTest(w, p)

        if (star.env$ExitCode != 0)
        {
            add_report("STARCALC", "status", "finish")
            return()
        }
    }

    # print observations for variables specified for model
    P_Obs(n1, n2)

    add_report("STARCALC", "status", "finish")
}
