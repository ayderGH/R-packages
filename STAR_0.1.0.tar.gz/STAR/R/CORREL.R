#' Calculate augmented correlation matrix and other summary statistics.
#' See Stringer & Stewart p 232 for a description of the matrix.
#'
#' The principal variables used are:
#'  
#' star.env$x_x[][] =  correlation matrix
#' n1         =  first row to be used
#' n2         =  last row to be used
#' star.env$k =  total number of x variables (highest column number)
#' w          =  x variable number to be used for weighting, 0 if none
#' p          =  factor to be used for autocorrelation transf, 0 if none
correlate <- function(n1, n2, w, p) {
    x <- array(0, dim = star.env$MAX_COLS)  # row of observations
    n <- as.integer()  # number of observations used
  
    # initialization -- set everything to zero
    star.env$xbar <- array(0, dim = star.env$k+1)
    star.env$sqrt_ss_x <- array(0, dim = star.env$k+1)
    star.env$x_x <- matrix(0, nrow = star.env$k+1, ncol = star.env$k+1)
    
    # calculate sums and cross products for observations n1 through n2
    for(i in n1:n2) {
        x <- get_row(x, i, w, p)
        
        # Accumulate line into matrix of sum of squares & cross products.
        # Note that only the top triangle of the matrix needs to be calculated
        # since the matrix is symmetric.
        for(s in 0:star.env$k) {
            for(t in s:star.env$k) {
                star.env$x_x[s+1, t+1] <- star.env$x_x[s+1, t+1] + x[s+1] * x[t+1]
            }
            star.env$xbar[s+1] <- star.env$xbar[s+1] + x[s+1]  #use xbar to accumulate sums
        }
    }
    
    # compute a correlation matrix and other summary statistics
    n <- n2 - n1 + 1
    
    # means
    for(j in 0:star.env$k) {
        star.env$xbar[j+1] <- star.env$xbar[j+1] / n
    }
    
    # corrected squares and std deviations
    for(j in 0:star.env$k) {
        star.env$x_x[j+1, j+1] <- star.env$x_x[j+1, j+1] - n * star.env$xbar[j+1] * star.env$xbar[j+1]
        
        if (star.env$x_x[j+1, j+1] <= 0) {
            star.env$x_x[j+1, j+1] <- 0
        }
        
        star.env$sqrt_ss_x[j+1] <- sqrt(star.env$x_x[j+1, j+1])
    }
    
    # corrected cross-products -- top triangle only
    for(s in 0:(star.env$k-1)) {
        for(t in (s+1):star.env$k) {
            star.env$x_x[s+1, t+1] <- star.env$x_x[s+1, t+1] - n * star.env$xbar[s+1] * star.env$xbar[t+1]
            if (star.env$sqrt_ss_x[s+1] == 0 | star.env$sqrt_ss_x[t+1] == 0)
                star.env$x_x[s+1, t+1] <- 0
        }
    }
    
    # Coefficients of correlation.  Top triangle only is calculated.
    # Exclude the diagonal itself (values are 1.0).  Since matrix
    # is symmetric, bottom triangle elements are copied from top
    for (i in 0:(star.env$k-1)) {
        for (j in (i+1):star.env$k) {
            if (star.env$sqrt_ss_x[i+1] != 0 & star.env$sqrt_ss_x[j+1] != 0) {
                star.env$x_x[i+1, j+1] <- star.env$x_x[i+1, j+1] / (star.env$sqrt_ss_x[i+1] * star.env$sqrt_ss_x[j+1])
            }
            
            # fill bottom triangle element
            star.env$x_x[j+1, i+1] <- star.env$x_x[i+1, j+1]
        }
    }
    
    # set diagonal elements to exactly 1.0 (i.e. 100% correlation)
    for(i in 0:star.env$k)
        star.env$x_x[i+1, i+1] <- 1
}