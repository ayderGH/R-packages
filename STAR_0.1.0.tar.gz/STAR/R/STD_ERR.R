#***************************************************************************
# STD_ERR.R
#***************************************************************************

#' Calculate the standard error of the individual residual. In this algorithm
#' cx is the scalar that results from pre- and post-multiplying the inverse matrix
#' by the vector of x-deviations for the period ip. se_res is the required
#' std error. See Stringer & Stewart section 9.6.
standard_error <- function(i, w, p) {
    c <- array(NA, dim = star.env$MAX_COLS)  # deviations from means
    cx_xc <- as.double()            # calculation factor
    accum <- as.double()            # accumulator
    se_res <- as.double()           # standard error of the individual residual
    se_orig <- as.double()          # standard error before factor
    n <- as.integer()               # number of observations in base
    s <- as.character()
        
    # initialize se_res to std error of the regression function
    se_res <- star.env$std_err_beta[1]
    
    # std error adjusted for heteroscedasticity
    if (w != 0) {
        se_res <- se_res * abs(get_x(i, w))
    }
    
    # Last line replaces
    # se_res *= get_x (i, w);
    # Change made 5/17/92 to fix bug reported in which system did not
    # handle negative Xs correctly
    
    # calculate deviations from the means
    c <- get_row(c, i, w, p)
    for (j1 in 1:star.env$k) {
        c[j1+1] <- ifelse(star.env$beta[j1+1] == 0.0, 0.0, c[j1+1] - star.env$xbar[j1+1])
    }
    
    # number of observations in base
    n <- star.env$n_last_base - star.env$n_first_base + 1
    
    # calculate cx_xc by pre- and post-multiplying x_x by c
    cx_xc <- 0.0
    
    for (j1 in 1:star.env$k) {
        if (star.env$beta[j1+1] != 0.0) {
            accum <- 0.0
            for (j2 in 1:star.env$k)
            {
                if (star.env$beta[j2+1] != 0.0)
                    accum <- accum + c[j2+1] * star.env$x_x[j2+1, j1+1]
            }
            accum <- accum * c[j1+1]
            cx_xc <- cx_xc + accum
        }
    }
    
    se_orig <- se_res
    
    # put it all together -- see Stringer & Stewart p 233
    se_res <- se_res * sqrt (1.0 + 1.0 / n + cx_xc)
    
    add_report("STDERR", "se_orig", se_orig)
    add_report("STDERR", "cx_xc", cx_xc)
    add_report("STDERR", "se_res", se_res)
    
    return(se_res)
}