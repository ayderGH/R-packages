# ***************************************************************************
#   T_VALUE.R
# ****************************************************************************

#' Calculate a t-percentile given the risk and degrees of freedom.
#' t is the t percentile, z is the corresponding normal percentile.
#' t_risk is the area under the t distribution to the left of
#' t_value. The algorithm presented here works for probability
#' of < 0.5. So if probability > 0.5 we solve for q = 1 - prob and then
#' flip the resulting t value. We can do this because of the symmetry of the
#' t distribution about 0.
#' 
#' . .
#' .     .
#' .       .
#' .         .
#' .           .
#' . x             .
#' .  x x                .
#' --------|-----|------------
#'     t
# ****************************************************************************/
#'
#' Modified 10/23/95 for STARWizard - AN
#' Modified 6/26/2010, TRS: Corrected line "t = z +..." where "-15*z" had been incorrectly "+15*z";
#' increased the precision by adding an additional term to "t = z +...";
#' and added references to Abramowitz & Stegun
t_value <- function(t_risk, df) {
    t <- as.double()  # t value
    z <- as.double()  # normal percentile
    q <- as.double() # probability < 0.5 used in algorithm
    g1 <- g2 <- g3 <- g4 <- as.double()  # factors used in calculation
    t2 <- t3 <- as.double()
    z3 <- z5 <- z7 <- z9 <- as.double()
    v <- as.double()  # degrees of freedom expressed as double
        
    v <- df
    
    # if probablility == 0.5 then t value is mean of t distribution (ie 0)
    if (t_risk == 0.5)
        return(0.0);
    
    # if probability is > 0.5 then solve for its complement
    q <- ifelse(t_risk < 0.5, t_risk, 1 - t_risk)
    
    # calculate z, the normal percentile as first approx to t value, Abramowitz & Stegun, p.933
    t <- sqrt(log (1.0 / (q*q) ) )
    
    t2 <- t*t 
    t3 <- t2*t
    
    z <- t - (star.env$C_C0 + star.env$C_C1*t + star.env$C_C2*t2) / (1 + star.env$C_D1*t + star.env$C_D2*t2 + star.env$C_D3*t3)
    
    # final modification of z to obtain t value, Abramowitz & Stegun, p.949
    z3 <- z*z*z 
    z5 <- z3*z*z 
    z7 <- z5*z*z 
    z9 <- z7*z*z
    
    g1 <- (z3 + z) / 4
    g2 <- (5*z5 + 16*z3 + 3*z) / 96
    g3 <- (3*z7 + 19*z5 + 17*z3 - 15*z) / 384
    g4 <- (79*z9 + 776*z7 + 1482*z5 - 1920*z3 - 945*z) / 92160
    
    t <- z + g1/v + g2/(v*v) + g3/(v*v*v) + g4/(v*v*v*v)
    
    return(ifelse(t_risk < 0.5, -t, t))
}
