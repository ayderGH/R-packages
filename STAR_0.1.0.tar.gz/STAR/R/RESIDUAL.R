# ****************************************************************************
# residual.R
# *****************************************************************************

#' This function returns the residual from an OLS or GLS regression function.
#' 
#' In the case of an OLS function the residual is:
#' f(t) = Y(t) - (beta[0]*X1(t) + beta[2]*X2(t) +... + beta[k]*Xk(t))
#' 
#' In the case of a GLS function the residual is:
#' f(t) = Y(t) - (beta[0]*X1(t) + beta[2]*X2(t) +... + beta[k]*Xk(t) + p*e(t-1))
#' for t > 1, and
#' f(1) = Y(1) - (beta[0]*X1(1) + beta[2]*X2(1) +... + beta[k]*Xk(1) + sqrt(1-p*p)*e(1))
#' for t = 1
#' where
#' e(t) = Y(t) - (beta[0]*X1(t) + beta[2]*X2(t) +... + beta[k]*Xk(t))
#' for all t
residual <- function(t, w, p) {
    
    e <- as.double()  # residual for period t as defined above
    f <- as.double()  # returned residual
    x <- array(0.0, dim = star.env$MAX_COLS)  # row of x values
    
    # get row of observations for period t. Note observations will be weighted if necessary
    # but will not have been transformed for autocorrelation (w > 0 possibly, but p=0.0)
    x <- get_row(x, t, w, 0.0)  
    
    # set residual equal to regression constant as first stage in summation
    e <- star.env$beta[1]
    
    # accumulate terms in regression
    for (j in 1:star.env$k) {
        if (star.env$beta[j+1] != 0.0) {
            e <- e + star.env$beta[j+1] * x[j+1]
        }
    }
    
    # residual is recorded Y minus function
    e <- x[1] - e
    
    # job done if no autocorrelation
    if (p <= 0.0) {
        return(e)
    }
    
    # adjust for previous residual e_1
    f <- ifelse(t == star.env$n_first_base, e - e * sqrt(1.0 - p*p),  e - p * star.env$e_1)
    
    # initialize e_1 for next invocation of the function
    star.env$e_1 <- e
    
    return(f)
}