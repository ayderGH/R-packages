# **************************************************************************
# PROJDISC.R
# **************************************************************************



#' Perform test for discontinuity between the base and projection periods
#' See Stringer & Stewart section 8.3.2, p 172
proj_discontinuity <- function() {
  
    add_report("PROJDISC", "status", "start")
    
    sse_A <- as.double()  # residual sum of squares for augmented data
    
    # F statistic, F tail probability:
    F <- as.double()
    F_prob <- as.double()  
    
    # degrees of freedom for F test:
    df_num <- as.double()
    df_den <- as.double() 
    
    # bypass test if no projection period
    if (star.env$n_last_proj <= star.env$n_last_base){
        add_report("PROJDISC", "status", "finish", "n_last_proj <= n_last_base")
        return(0)
    }
    
    # DisplayStatus (GetStrTblEntry(  PROJDISC_0  ));
    
    # regress on augmented set [base+projection] - this is required
    # in order to test for discontinuity between base and projection
    # but first store stats for base period
    
    store_stats()
    
    sse_A <- sum_of_squares(star.env$n_first_base, star.env$n_last_proj)
    restore_stats()
  
    # check for pathological condition
    if (sse_A <= 0.0 | sse_A <= star.env$sse) {
        add_report("PROJDISC", "status", "finish", "sse_A <= 0.0 | sse_A <= star.env$sse")
        return(0)
    }
  
  
    # set degrees of freedom for F test
    df_num <- star.env$n_last_proj - star.env$n_last_base
    df_den <- (star.env$n_last_base - star.env$n_first_base + 1) - variable_count() - 1
    
    # F statistic for test --  see Stringer & Stewart p 172
    F <- ((sse_A - star.env$sse) / df_num) / (star.env$sse / df_den)
    
    # Tail probability for F statistic 
    F_prob <- F_test (F, df_num, df_den)
    
    # print details
    add_report("PROJDISC", "sse_A", sse_A) 
    add_report("PROJDISC", "sse", star.env$sse)
    add_report("PROJDISC", "df_num", df_num)
    add_report("PROJDISC", "df_den", df_den)
    add_report("PROJDISC", "F", F)
    add_report("PROJDISC", "F_prob", F_prob*100)
    add_report("PROJDISC", "star.env$SIGLEV_DISC_PROJ", star.env$SIGLEV_DISC_PROJ*100)
    
    # print message and return 1 if discontinuity, else return 0
    if (F_prob < star.env$SIGLEV_DISC_PROJ) {
        add_report("PROJDISC", "status", "finish", "F_prob < star.env$SIGLEV_DISC_PROJ")
        return(1)
    }
    else {
        add_report("PROJDISC", "status", "finish", "F_prob >= star.env$SIGLEV_DISC_PROJ")
        return(0)
    }
}
