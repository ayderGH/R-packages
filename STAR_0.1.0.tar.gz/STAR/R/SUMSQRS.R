# ***************************************************************************
# sumsqrs.R 
# ***************************************************************************

#' Calculate the residual sum of squares for least squares
#' regression on data for periods n1 through n2.
sum_of_squares <- function(n1, n2){
    # Calculate correlation matrix
    correlate (n1, n2, 0, 0)
    
    # Transform matrix for admission of variables selected for entire base
    for (j in 1:star.env$k)
        if (star.env$beta[j+1] != 0 & star.env$x_x[j+1, j+1] > star.env$TOLERANCE)
            gauss_jordan(j)
    
    # correct for possible pathological condition
    if (star.env$x_x[1, 1] < 0) {
        star.env$x_x[1, 1] <- 0
    }
    
    # return residual sum of squares -- see Stringer & Stewart p 223 for example
    return(star.env$sqrt_ss_x[1] * star.env$sqrt_ss_x[1] * star.env$x_x[1, 1])
}