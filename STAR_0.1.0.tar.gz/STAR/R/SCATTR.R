# **************************************************************************
#  SCATTR.R 
# ****************************************************************************
#  This function prints scaled scatter diagrams coordinates. 
#  By default 0 < x, y < 1
# ***************************************************************************/

scattr <- function (height = 1, width = 1) {
    scattr <- list()
    scattr_row <- 1
    for (jy in 1:(star.env$k - star.env$seas_adj * star.env$periods_per_year)) {
        for (jx in (jy + 1):(star.env$k - star.env$seas_adj * star.env$periods_per_year + 1)) {
            scattr[[scattr_row]] <- P_Scattr(jy, jx, height, width)
            scattr_row <- scattr_row + 1
        }
    }
    add_report("SCATTR", "num_diagrams", scattr_row - 1)
    add_report("SCATTR", "scattr", scattr)
    #print(scattr)
}

P_Scattr <- function (jy, jx, height = 1, width = 1) {
    # initialize variables
    n1 <- min (star.env$n_first_base, max (star.env$n_first_proj, 0))
    n2 <- max (star.env$n_last_base, star.env$n_last_proj)
    #x2 <- as.numeric()
    #y2 <- as.numeric()
    #xy <- as.numeric()
    
    #x_mean <- y_mean <- x2 <- y2 <- xy <- r <- 0
  
    x_min <- y_min <- x_Max <- y_Max <- NULL
    
    # calculate vertical and horizontal maxima and minima plus other summary statistics
    for (i in n1:n2) {
        x <- get_x (i, jx-1)
        y <- get_x (i, jy-1)
        
        if (is.null(x_min)) {
            x_min <- x_Max <- x
            y_min <- y_Max <- y
        }
        else {
            x_min  <-  min (x,  x_min)
            x_Max  <-  max (x,  x_Max)
            y_min  <-  min (y,  y_min)
            y_Max  <-  max (y,  y_Max)
        }
        
        # summary statistics for base profile only
        #if (i >= star.env$n_first_base  &  i <= star.env$n_last_base) {
        #    x_mean <- x_mean + x
        #    y_mean <- y_mean + y
        #    x2 <- x2 + as.numeric(x) * as.numeric(x)
        #    y2 <- y2 + as.numeric(y) * as.numeric(y)
        #    xy <- xy + as.numeric(x) * as.numeric(y)
        #    
        #}
    }
 
    #n <- star.env$n_last_base - star.env$n_first_base + 1
    #x_mean <- x_mean / n
    #y_mean <- y_mean / n
    #x2 <- x2 - n * x_mean * x_mean
    #y2 <- y2 - n * y_mean * y_mean
    #xy <- xy - n * x_mean * y_mean
    #r <- ifelse(x2 > 0 & y2 > 0, xy / (sqrt (x2) * sqrt (y2)), 0)
    
    # scaling factors to convert (x, y) plane to (Tx, Ty) plane
    x_scale  <-	width	/ (x_Max - x_min)
    y_scale  <-	height / (y_Max - y_min)
    
    coords <- array (dim = c(0, 2))
    colnames(coords) <- c("var1", "var2")
                     
    for ( i in n1:n2) {
        # transform (x, y) to (Tx, Ty)
        Tx <- (get_x (i, jx-1) - x_min) * x_scale 
        Ty <- (get_x (i, jy-1) - y_min) * y_scale
        coords <- rbind(coords, c(Tx, Ty))
    }
    
    return (list (var1 = list (name = as.character(star.env$variable$name[jy]),
                               symbol = as.character(star.env$variable$symbol[jy])),
                  var2 = list (name = as.character(star.env$variable$name[jx]),
                               symbol = as.character(star.env$variable$symbol[jx])),
                  coords = coords))
}