# ***************************************************************************
# storstat.R
# ***************************************************************************
# Store / restore certain selected statistics
# ***************************************************************************/

star.env$temp_sqrt_ss_x <- as.array(NA)
star.env$temp_xbar <- as.array(NA)
star.env$temp_x_x <- as.array(NA)


# store_stats () stores the stats in an array temp_array []
store_stats <- function() {
    i <- j <- as.integer()
    
    star.env$temp_sqrt_ss_x <- array(dim = star.env$k + 1)
    star.env$temp_xbar <- array(dim = star.env$k + 1)
    
    star.env$temp_x_x <- array(dim = c(star.env$k + 1, star.env$k + 1))
    
    # store x_x
    for (i in 0:star.env$k)
    {
        for (j in 0:star.env$k)
            star.env$temp_x_x[i+1, j+1] <- star.env$x_x[i+1, j+1]
    }
    
    # store xbar
    for (i in 0:star.env$k)
        star.env$temp_xbar[i+1] <- star.env$xbar[i+1]
    
    # store sqrt_ss_x
    for (i in 0:star.env$k)
        star.env$temp_sqrt_ss_x[i+1] <- star.env$sqrt_ss_x[i+1]
}


#' restore_stats () recovers them
restore_stats <- function() {
    i <- j <- as.integer()
    
    for (i in 0:star.env$k){
        for (j in 0:star.env$k)
            star.env$x_x[i+1, j+1] <- star.env$temp_x_x[i+1, j+1]
    }
    star.env$temp_x_x <- NULL
    
    for (i in 0:star.env$k)
        star.env$sqrt_ss_x[i+1] <- star.env$temp_sqrt_ss_x[i+1]
    star.env$temp_sqrt_ss_x <- NULL
    
    for (i in 0:star.env$k)
        star.env$xbar[i+1] <- star.env$temp_xbar[i+1]
    star.env$temp_xbar <- NULL
}