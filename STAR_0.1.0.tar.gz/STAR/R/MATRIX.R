#' ***************************************************************************
#' MATRIX.R
#' ****************************************************************************

#' These functions provide the means by which the other functions in the
#' STAR system deal with the observation matrix.  
#' This implementation can be readily changed without affecting the rest of the system.
#'  
#' In this implementation the observation matrix is stored in a dynamic
#' 'two-dimensional' array.  Element z[i, j] is in row i, column j.
#' ****************************************************************************
matrix_malloc <- function(n, k) {
    tryCatch({
        # all this function does is set the number of rows and columns
        star.env$total_n <- n
        star.env$real_k <- k
        star.env$real_k_plus1 <- k + 1
        star.env$z <- matrix(nrow = n+1, ncol = star.env$real_k_plus1)
    },
    error = function(e) {
        return(star.env$BAD_APPLICATION)
    })
    
    return(star.env$OK)
}
  
matrix_free <- function() {
    star.env$z <- NULL
    star.env$total_n <- 0
    star.env$real_k <- 0
    star.env$real_k_plus1 <- 0
}

put_x <- function(x, i, j)
{
    # put an element into the array -- conceptually z[i, j] = x
    star.env$z[i+1, j+1] <- x
}
  
get_x <- function(i, j) {
    # get an element from the array -- conceptually, x = z[i][j]
    if (j <= star.env$real_k)
        return(star.env$z[i+1, j+1])
    # if a seasonal variable element is being requested return 1 or 0 as appropriate
    else
        return(ifelse((j - star.env$real_k == 1 + (i %% star.env$periods_per_year)) & star.env$seas_adj, 1.0, 0.0))
}