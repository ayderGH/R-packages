#***************************************************************************
# MAS.R
#***************************************************************************
    
CONVERGE_TOL <- 0.001
MAX_ITERATIONS <- 31

MAS_func <- function(z, c, pq)
{
    # derivative of normal distribution function
    norm_deriv <- exp(-z * z / 2) / star.env$SQRT_2_PI
    
    # normal distribution function 
    pq <- NormProb(z)
    
    return(list(mas = (norm_deriv / pq - c), q = pq))
}

#' Find the most adverse spread of error mp, r and the standard error of the
#' projection.
#' 
#' The process is an iterative one using an approximation to the normal
#' distribution function and its first derivative (the density function).
most_adverse_spread <- function(r_factor, mp, se_res) {
    
    q <- as.double()
    
    # initialization
    c <- r_factor / (mp / se_res)
    lower <- upper <- 0
    n_iterations <- 1
    
    # the first approx to the root of f(z) = 0 is z=0 */
    z <- z_1 <- 0.0
    mas_res <- MAS_func(0.0, c, q)  # calculate f(0)
    f <- mas_res$mas   
    q <- mas_res$q
    s_1 <- sign(f)
    
    # The search for a root is confined to the z interval
    # [lower, upper] = [0, 5] for f(0) > 0
    # [upper, lower] = [-5, 0] for f(0) < 0
    # Since f is a monotonically decreasing function its root
    # will be positive if f(0) > 0 and negative if f(0) < 0
    # The boundary 5 (or -5) was chosen because 5 is a very large
    # standard normal deviate.
        
    upper <- s_1 * 5  # upper is set to 5 or -5
    
    while (n_iterations < MAX_ITERATIONS) {
        z <- (lower + upper) / 2  # bisect the interval
        
        mas_res <- MAS_func(z, c, q)  # find f(z)
        f <- mas_res$mas   
        q <- mas_res$q
        
        if (abs(z - z_1) < CONVERGE_TOL) {  # process has converged on root
            break
        }
        s <- sign(f) * s_1
                
        # if the sign of f(z) is different to that of f(0), ie s < 0 then the root lies between the lower boundary and z
        if (s < 0)
            upper <- z  # so set the upper boundary to z
                            
        # if the sign of f is the same as that of f(0), ie s > 0 then the root lies between the upper boundary and z
        if (s > 0)
            lower <- z  # so set the lower boundary to z
                                    
        # set z_1 to z for next iteration
        z_1 <- z
        
        n_iterations <- n_iterations + 1
    }
    
    if (n_iterations == MAX_ITERATIONS)
    {
        # PrtLine (GetStrTblEntry(  MAS_0  ), 1, 1);
        star.env$ExitCode <- star.env$BAD_APPLICATION
        return(0.0)
    }
    
    # now we've found the most adverse spread
    # mas = round (-r_factor / log(q), 0);

    # it must not be less than 1
    # mas = max (mas, 1.0);

    # New in Version 3.20, 6/7/2010 TRS, unrounded MAS
	mas <- max(-r_factor / log(q), 1.0)

    return(mas)
}