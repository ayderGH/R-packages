#' ***************************************************************************
#' EBLTEST.R
#' ****************************************************************************

#' Project an ending balance. This works by projecting one of the components
#' of an account and adjusting the recorded ending balance by the total residual
#' to get to the projected ending balance on the account.
#'
#' The most common application is projecting cash receipts in order to estimate
#' the balance on accounts receivable. The total residual difference between
#' recorded and estimated cash receipts is used to adjust the balance on
#' recorded accounts receivable to get to estimated accounts receivable.
#'
#' The direction of test that is specified is that which relates to the
#' component being projected (eg cash receipts for understatement). Depending
#' on the nature of the projected component (debit or credit) the direction
#' of test of the component is translated into an appropriate test of the ending
#' balance (eg overstatement of accounts receivable). The optional sample is
#' designed based on the recorded ending balance (overstatement) or the projected
#' ending balance (understatement).
#' ***************************************************************************/
EndbalTest <- function(w, p) {
    y <- as.double()                # recorded y value (component)
    e <- as.double()                # residual (component)
    y_est <- as.double()            # regression estimate of y (component)
    est_bal <- as.double()          # estimated balance
    se_res <- as.double()           # standard error of the residual
    sum_var <- as.double()          # sum of the variances in the projection period 
    excess_under <- as.double()     # excess to be investigated 
    excess_over <- as.double()      # excess to be investigated in opposite direction 
    least_excess <- as.double()     # smallest excess to be investigated 
    opt_sample <- as.double()       # optional sample size 
    j <- as.double()                # sampling interval (j factor) 
    threshold <- as.double()        # threshold for excess 
    population <- as.double()       # recorded or estimated ending balancedepending on direction 
    dir_bal <- as.integer()         # direction of test applicable to ending balance 
    sum_y <- as.double()            # sum of recorded y values (component)
    sum_e <- as.double()            # sum of residuals 
    sum_y_est <- as.double()        # sum of projections 
    risk_at_start <- as.double()    # risk equivalent to input R factor
    risk_mas <- as.double()         # risk adjusted for most adverse spread or error
    mas <- as.double()              # most adverse spread of error
    ndec <- as.integer()            # number of decimals for y component
    round_factor <- as.double()     # factor used in rounding sampling interval
    FlipFlag <- star.env$OFF                 # flag to flip calc of balance and direction of test
    paradox_flag <- star.env$OFF
    t <- as.double()
  
    add_report("EBLTEST", "status", "start")
    
    ndec <- star.env$variable$decimals[1]
    round_factor <- 10^ndec
    
    # smallest excess is least significant digit
    least_excess <- 1 / round_factor
    
    # Calculate std error inverse matrix
    invert_matrix()
    
    # Initialize constants and accumulators
    sum_y <- sum_e <- sum_y_est <- sum_var <- 0
    risk_at_start <- exp(-star.env$r_factor)
    
    # If the account and component are matched types (ie asset and debit
    # or liability and credit) then the estimated balance is simply the
    # recorded balance minus the residual and the direction of test for
    # the balance is the same as that for the component.
    
    # If they are unmatched (ie asset and credit or liability and debit)
    # then the calculations are flipped. Estimated balance is recorded
    # balance minus residual and the direction of test for the balance is
    # the opposite of the direction of test specified for the component.
    
    FlipFlag <- ifelse(((star.env$account_type == star.env$ASSET & star.env$component_type == star.env$DEBIT) 
                        | (star.env$account_type == star.env$LIABILITY & star.env$component_type == star.env$CREDIT)), star.env$OFF, star.env$ON)
    
    # print heading
    add_report("EBLTEST", "mp_entered", star.env$mp_entered)
    add_report("EBLTEST", "ndec", ndec)
    add_report("EBLTEST", "testing_strategy", star.env$testing_strategy)
    add_report("EBLTEST", "r_factor", star.env$r_factor)
    
    # This next line seems silly, but it initializes the previous residual
    # (to the last base period). It is needed in case of autocorrelation.
    # If this is not done the last base period residual (a static
    # double in residual()) may not be correct in certain circumstances
    # (eg, if the residuals have just been plotted)
    
    proj <- projection(ifelse(star.env$n_first_proj > 0, star.env$n_first_proj - 1, 0), w, p)
    y <- proj$y
    y_est <- proj$y_est
    e <- proj$e
  
    # Main loop begins here with input from projection profile
    for (i in star.env$n_first_proj:star.env$n_last_proj) {
        # print observation number
        add_report("EXCESS", "observation_number", i+1)
        
        proj <- projection(i, w, p)
        y <- proj$y
        y_est <- proj$y_est
        e <- proj$e
        
        # Accumulate total y, estimate and residual
        sum_y <- sum_y + y
        sum_y_est <- sum_y_est + y_est
        sum_e <- sum_e + e
        
        # Calculate standard error of projection
        se_res <- standard_error(i, w, p)
        
        # accumulate variance
        sum_var <- sum_var + se_res * se_res
    }
  
    # test of total residual
  
    # total std error of residual is sqrt of sum of individual std errs
    se_res <- sqrt(sum_var)
    
    # print total std error of residual
    add_report("STD_ERR", "se_res", se_res)
    
    # Calculate most adverse spread of error and associated risk
    mas <- most_adverse_spread(star.env$r_factor, star.env$mp, se_res)
    risk_mas <- risk_at_start^(1/mas)
    if (star.env$ExitCode)
    {
        add_report("EBLTEST", "status", "finish")
        return()
    }
  
    # print the most adverse risk calculation
    add_report("P_RISK", "risk_at_start", risk_at_start)
    add_report("P_RISK", "mas", mas)
    add_report("P_RISK", "risk_mas", risk_mas)
    
    # calculate threshold and excess
    t <- t_value (risk_mas, star.env$df)
    threshold <- star.env$mp / mas + se_res * t
    
    # Y Variable (Component) 
    add_report("EBLTEST", "variable_name", star.env$variable$name[1])
    add_report("EBLTEST", "sum_y", sum_y)
    add_report("EBLTEST", "ndec", ndec)
    add_report("EBLTEST", "component_type", ifelse(star.env$component_type == star.env$CREDIT, "star.env$CREDIT", "star.env$DEBIT"))
    add_report("EBLTEST", "sum_y_est", sum_y_est)
    add_report("EBLTEST", "sum_e",  sum_e)
    
    # calc sum_e and estimated balance based on FlipFlag
    sum_e <- ifelse(FlipFlag, -sum_e, sum_e)
    est_bal <- star.env$rec_bal - sum_e
    excess_under <- sum_e + ifelse(threshold < -least_excess, sum_e + threshold, 0)
    excess_over <- sum_e - ifelse(threshold > least_excess, sum_e - threshold, 0)
    
    # recorded balance, estimated balance
    add_report("EBLTEST", "bal_name", star.env$bal_name)
    add_report("EBLTEST", "rec_bal", star.env$rec_bal)
    add_report("EBLTEST", "ndec", ndec)
    add_report("EBLTEST", "account_type", ifelse(star.env$account_type == star.env$ASSET, "star.env$ASSET", "star.env$LIABILITY"))
    add_report("EBLTEST", "FlipFlag", FlipFlag)
    add_report("EBLTEST", "est_bal", est_bal)
    add_report("EBLTEST", "ndec", ndec)
    
    # threshold
    add_report("EBLTEST", "threshold", threshold)
    
    # excess
    add_report("EBLTEST", "excess_under", excess_under)
    add_report("EBLTEST", "excess_over", excess_over)          
    
    # paradoxical excess ?
    paradox_flag = ifelse((threshold < 0 & (excess_under | excess_over)), star.env$ON, star.env$OFF)
    add_report("EBLTEST", "paradox_flag", paradox_flag)
    
    add_report("EBLTEST", "status", "finish")
}