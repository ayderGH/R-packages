#' Calculate a GLS function -- See Stringer & Stewart p 177:
#' 1. Calculate a correlation matrix based on transformed variables
#' 2. Invert matrix by admitting the variables previously admitted in OLS function
#' 3. Calculate an OLS function based on the transformed variables
#' 4. Retransfrorm the regression constant. The coefficients remain the same
GLS_function <- function(w, p){
    
    # correlation matrix for transformed variables -- note parameter p
    correlate(star.env$n_first_base, star.env$n_last_base, w, p)
    
    # transform matrix and calculate function
    for (j in 1:star.env$k) {
        if (star.env$beta[j+1] != 0 & star.env$x_x[j+1, j+1] > star.env$TOLERANCE)
            gauss_jordan(j)
    }
    
    calc_function()
    
    # transform regression constant
    star.env$beta[1] <- star.env$beta[1] / (1 - p)
}