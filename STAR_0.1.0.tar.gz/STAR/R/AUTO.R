#' Test and adjust for autocorrelation as follows:
#' 1. Test residuals for autocorrelation. If none then return.
#' 2. Calculate p, the coefficient of autocorrelation.
#' 3. Calculate a GLS function.
#' 4. Test the GLS residuals for autocorrelation.
#' 5. If autocorrelated goto 2.
#' 6. Do up to 3 iterations of steps 2 through 4. Autocorrelation is considered
#' untreatable if it is not removed at this stage.
#'
#' See Stringer & Stewart section 8.4.
autocorrelation <- function(w) {
    
    add_report("AUTO", "status", "start")
    
    p <- 0  # coefficient of autocorrelation
    num_iterations <- 0  # number of iterations

    # If no autocorrelation then return
    if (!DW_test(w, 0)) {
        add_report("AUTO", "status", "finish", "DW_test == 0")
        return(0)
    }

    # The following loop
    # 1. calculates the coefficient of autocorrelation p
    # 2. uses p to calculate a GLS function
    # 3. tests the GLS function for autocorrelation
    # The loop is executed a maximum of three times and is exited
    # when autocorrelation is no longer present
    
    repeat {
        num_iterations <- num_iterations + 1
        
        if (num_iterations > 3) {
            add_report("AUTO", "status", "finish")
            return(star.env$FATAL_AUTOCORRELATION)
        }
        
        p <- rho(w, p)
        GLS_function(w, p)
        
        add_report("AUTO", "w", w)
        add_report("AUTO", "p", p)
        add_report("AUTO", "num_iterations", num_iterations)

        if (!DW_test(w, p)) {
            break
        }
    }
    
    add_report("AUTO", "status", "finish")
    
    return(p)
}