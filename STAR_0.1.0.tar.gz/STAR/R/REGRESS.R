star.env$MAXSTEPS <- 60
star.env$ADMIT_VAR <- 1
star.env$NO_ADMIT_VAR <- 0
star.env$ELIM_VAR <- 1
star.env$NO_ELIM_VAR <- 0

# -------------------------------------------------------------------------
star.env$F_level_x <- array(dim = star.env$MAX_COLS, 0)
star.env$cum_F_level <- as.double()
star.env$v_max <- as.double()        # highest v-statistic
star.env$v_min <- as.double()        # lowest v-statistic
star.env$next_in <- as.integer()     # variable number of v_max variable
star.env$next_out <- as.integer()    # variable number of star.env$v_min variable
star.env$last_out <- as.integer()    # number of most recently eliminated variable
# -------------------------------------------------------------------------

#' This function controls the stepwise selection procedure
#' this procedure consists of :
#' 1) identifying the most significant new variable not already in
#' the regression and the least significant variable that is in
#' 2) eliminating redundant variables before
#' 3) admitting a new one
#'
#' The procedure ends when either there are no more eligible x
#' variables or when among those that are eligible there is none that
#' is statistically significant
#'
#' See Stringer & Stewart Section 9.5 for a full description of the procedure.
regress <- function() {
    step <- as.integer()
    s <- as.character()
    
    add_report("REGRESS", "status", "start")
    
    # initialization
    star.env$df <- star.env$n_last_base - star.env$n_first_base
    star.env$cum_F_level <- 1.0 - star.env$SIGLEV_ADMIT
    star.env$F_level_x[1:(star.env$k+1)] <- 0
    star.env$last_out <- -1
    
    # first admit variables that are to be forced
    for (j in 1:star.env$k) {
        if (star.env$df <= 1) {
            break
        }
        
        if (star.env$force_x[j+1] & star.env$x_x[j+1, j+1] >= star.env$TOLERANCE) {
            gauss_jordan(j)
            star.env$df <- star.env$df - 1
            add_report("REGRESS", "variable_symbol", star.env$variable$symbol[j+1])
        }
    }
    
    if (star.env$df <= 1) {
        add_report("REGRESS", "status", "finish", "star.env$df <= 1")
        return()
    }
    
    # STEP NUMBER 1
    step <- 1
    next_in_next_out()
    
    if (admit() == star.env$NO_ADMIT_VAR) {
        add_report("REGRESS", "status", "finish", "admit() == NO_ADMIT_VAR")
        return()
    }
    star.env$df <- star.env$df - 1
    
    # STEP NUMBER 2
    step <- 2
    next_in_next_out()
    if (admit() == star.env$NO_ADMIT_VAR) {
        add_report("REGRESS", "status", "finish")
        return()
    }
    star.env$df <- star.env$df - 1
    
    # STEPS 3, 4, ... 
    #
    # there are now 2 variables in function.
    # in the following loop redundant variables are removed
    # and new significant variables admitted
    
    for (step in 3:star.env$MAXSTEPS) {
        next_in_next_out()
      
        # perform backward elimination until no more to eliminate
        while (eliminate() == star.env$ELIM_VAR){
            star.env$df <- star.env$df + 1
            step <- step + 1
            next_in_next_out()
        }
      
        # perform forward selection. if admitted loop back. else end
        if (admit() == star.env$NO_ADMIT_VAR) {
            break
        }
        star.env$df <- star.env$df - 1
    }
    
    if (step > star.env$MAXSTEPS) {
        add_report("REGRESS", "status", "finish", "star.env$BAD_APPLICATION")
        star.env$ExitCode <- star.env$BAD_APPLICATION
    }
    
    add_report("REGRESS", "status", "finish")
}


next_in_next_out <- function() {
    # identify the next variables to be tested for admission 
    # and elimination respectively
    v <- as.double()

    # initialize variables
    star.env$v_max <- 0
    star.env$v_min <- NA
    v <- 0
    star.env$next_in <- 1
    star.env$next_out <- 1
    
    # At the end of this loop the most significant variable not in the
    # function and the least significant in the function will have been found.
    for (j in 1:star.env$k) {
        if (star.env$x_x[j+1, j+1] <= star.env$TOLERANCE) {
            next
        }
      
        # j-th v-statistic -- Stringer & Stewart p 221
        v <- star.env$x_x[j+1, 1] * star.env$x_x[1, j+1] / star.env$x_x[j+1, j+1]
      
        # if v == 0 it won't be highest or lowest
        if (v == 0) {
            next
        }
        
        # if v > 0 then variable not in function -- test for v_max
        if (v > 0){
            # if j=last_out then variable was last to be eliminated
            if (v > star.env$v_max & j != star.env$last_out){
                star.env$v_max <- v
                star.env$next_in <- j
            }
        }
        
        if (v < 0) {
            # forced variables not to be considered for elimination
            if (star.env$force_x[j+1]) {
                next
            }
            
            if (is.na(star.env$v_min)) {
                star.env$v_min <- v
                star.env$next_out <- j
            } 
            
            if (abs(v) < abs(star.env$v_min)) {
                star.env$v_min <- v
                star.env$next_out <- j
            }
        }
    }
}


admit <- function() {
    # test for the admission of a new variable
    F <- as.double()
    star.env$F_level <- as.double()

    # definitely no admission if v_max is zero
    if (star.env$v_max == 0) {
        return(0)
    }
    
    # do not test if correlation already very high
    if (star.env$x_x[1, 1] < star.env$TOLERANCE) {
        return(0)
    }
    
    # compute f-value. if >= critical value then admit variable
    if (star.env$v_max < star.env$x_x[1, 1]){
        # Stringer & Stewart P 221
        F <- star.env$v_max * (star.env$df - 1) / (star.env$x_x[1, 1] - star.env$v_max)
        
        if (F == 0)
            return(star.env$NO_ADMIT_VAR)
        
        # get F level corresponding to F -- Stringer & Stewart P 232
        star.env$F_level <- 1 - F_test(F, 1, star.env$df - 1)
        
        # print details of test for admission
        add_report("REGRESS", "variable_symbol", star.env$variable$symbol[star.env$next_in + 1])
        add_report("REGRESS", "v_max", star.env$v_max)
        add_report("REGRESS", "x_x[1, 1]", star.env$x_x[1, 1])
        add_report("REGRESS", "F", F)
        add_report("REGRESS", "star.env$F_level", star.env$F_level)
        add_report("REGRESS", "star.env$cum_F_level", star.env$cum_F_level)
        
        # variable is not significant if it F level is below the target
        if (star.env$F_level < star.env$cum_F_level) {
            return(star.env$NO_ADMIT_VAR)
        }
    }
    else
        star.env$F_level <- 1  # pathological condition
    
    # keep track of star.env$F_level at which this variable has been admitted
    star.env$F_level_x[star.env$next_in+1] <<- star.env$F_level
    
    # increase the cumulative F level to be used for the next admission
    # Stringer & Stewart P 232
    star.env$cum_F_level <- star.env$cum_F_level / star.env$F_level
    
    # print the new target
    add_report("REGRESS", "star.env$cum_F_level", star.env$cum_F_level)

    # transform matrix to admit the variable
    gauss_jordan(star.env$next_in)
    
    # and print the new matrix
    add_report("REGRESS", "x_x", star.env$x_x)

    return (star.env$ADMIT_VAR)
}


eliminate <- function() {
    # test for the elimination of a variable already in the regression
    F <- as.double()
    star.env$F_level <- as.double()
    s <- as.character()
    
    # perfect correlation -- do not eliminate
    if (star.env$x_x[1, 1] == 0) {
        return(star.env$NO_ELIM_VAR)
    }
  
    # F statistic to test elimination
    F <- abs(star.env$v_min) * star.env$df / star.env$x_x[1, 1]
  
    # variable is eliminated if star.env$F_level is lower than level 1-star.env$SIGLEV_ELIM
    if (F > 0) {
        # get F level corresponding to F
        star.env$F_level <- 1 - F_test(F, 1, star.env$df)
      
        # and return if it exceeds the required confidence level
        if (star.env$F_level >= 1 - star.env$SIGLEV_ELIM)
            return(star.env$NO_ELIM_VAR)
    }
  
    # variable is to be eliminted
    star.env$last_out <- next_out
  
    # eliminate from cumulative confidence the effect of original admission of variable
    star.env$cum_F_level <- star.env$cum_F_level * F_level_x[next_out+1]
  
    # print info on elimination
    add_report("REGRESS", "abs(star.env$v_min)", abs(star.env$v_min))
    add_report("REGRESS", "x_x[1][1]", star.env$x_x [1, 1])
    add_report("REGRESS", "F", F)
    add_report("REGRESS", "star.env$F_level", star.env$F_level)
    add_report("REGRESS", "(1.0 - star.env$SIGLEV_ELIM)", (1.0 - star.env$SIGLEV_ELIM))
    add_report("REGRESS", "F_level_x [next_out+1]", F_level_x[next_out+1])
    add_report("REGRESS", "star.env$cum_F_level", star.env$cum_F_level)

    # transform matrix to eliminate the variable 
    gauss_jordan(next_out)
    
    # and print the matrix
    add_report("REGRESS", "x_x", star.env$x_x)
    
    return(star.env$ELIM_VAR)  # eliminated 
}