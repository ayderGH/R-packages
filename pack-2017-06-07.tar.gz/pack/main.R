library(STAR)

print(star.env$OK)